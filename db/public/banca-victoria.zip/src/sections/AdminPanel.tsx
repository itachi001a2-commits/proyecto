import { useState } from "react";
import type { SessionUser } from "@/store";
import { getNextBankNumber, localGetUsers, addCredit, formatMoney, logAudit } from "@/store";
import { trpc } from "@/providers/trpc";
import { quickSync } from "@/lib/sync";
import {
  Ticket, Users, Plus, ArrowLeft, Trash2,
  Settings, Trophy, Ban, BarChart3, ChevronRight, X, DollarSign, Wallet, Percent,
  ChevronLeft, UserMinus, UserPlus, Pencil, Shield, AlertTriangle, Lock
} from "lucide-react";

type AdminSection = "menu" | "loterias" | "grupos" | "usuarios" | "premios" | "ganadores" | "anular" | "reportes" | "limites" | "config";

interface AdminPanelProps {
  user: SessionUser;
}

const MENU_ITEMS = [
  { id: "loterias" as AdminSection, label: "Loterias", icon: Ticket, desc: "Gestionar loterias" },
  { id: "grupos" as AdminSection, label: "Grupos", icon: Users, desc: "Crear y editar grupos" },
  { id: "usuarios" as AdminSection, label: "Usuarios", icon: Users, desc: "Crear y gestionar usuarios" },
  { id: "premios" as AdminSection, label: "Premios", icon: DollarSign, desc: "Configurar premios por tipo" },
  { id: "ganadores" as AdminSection, label: "Ganadores", icon: Trophy, desc: "Numeros ganadores" },
  { id: "anular" as AdminSection, label: "Anular Tickets", icon: Ban, desc: "Anular tickets" },
  { id: "reportes" as AdminSection, label: "Reportes", icon: BarChart3, desc: "Ver reportes" },
  { id: "limites" as AdminSection, label: "Limites", icon: Ban, desc: "Limites y bloqueos de jugadas" },
  { id: "config" as AdminSection, label: "Configuracion", icon: Settings, desc: "Ajustes del sistema" },
];

export default function AdminPanel({ user: _user }: AdminPanelProps) {
  const [section, setSection] = useState<AdminSection>("menu");
  return (
    <div className="h-full flex flex-col">
      {section === "menu" ? (
        <MenuScreen onNavigate={setSection} />
      ) : (
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-100 bg-white sticky top-0 z-10">
            <button onClick={() => setSection("menu")} className="p-1.5 hover:bg-gray-100 rounded-lg">
              <ArrowLeft size={20} className="text-gray-600" />
            </button>
            <h2 className="text-lg font-bold text-gray-900">
              {MENU_ITEMS.find((m) => m.id === section)?.label}
            </h2>
          </div>
          {section === "loterias" && <LoteriasSection />}
          {section === "grupos" && <GruposSection />}
          {section === "usuarios" && <UsuariosSection />}
          {section === "premios" && <PremiosSection />}
          {section === "ganadores" && <GanadoresSection />}
          {section === "anular" && <AnularSection />}
          {section === "reportes" && <ReportesGrupoSection />}
          {section === "limites" && <LimitesSection />}
          {section === "config" && <ConfigSection />}
        </div>
      )}
    </div>
  );
}

function MenuScreen({ onNavigate }: { onNavigate: (s: AdminSection) => void }) {
  return (
    <div className="h-full overflow-y-auto custom-scrollbar px-4 py-4 space-y-2">
      <h2 className="text-xl font-bold text-gray-900 mb-4">Panel de Administracion</h2>
      {MENU_ITEMS.map((item) => (
        <button
          key={item.id}
          onClick={() => onNavigate(item.id)}
          className="w-full flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-100 hover:border-green-300 shadow-sm transition-all text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center shrink-0">
            <item.icon size={20} className="text-green-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-gray-900">{item.label}</p>
            <p className="text-xs text-gray-500">{item.desc}</p>
          </div>
          <ChevronRight size={16} className="text-gray-300 shrink-0" />
        </button>
      ))}
    </div>
  );
}

// ─── LOTERIAS ──────────────────────────────────────────────────────
const DAY_LABELS: Record<string, string> = {
  mon: "Lun", tue: "Mar", wed: "Mie", thu: "Jue",
  fri: "Vie", sat: "Sab", sun: "Dom",
};

const DEFAULT_SCHEDULE = {
  mon: { open: "07:00", close: "20:00" },
  tue: { open: "07:00", close: "20:00" },
  wed: { open: "07:00", close: "20:00" },
  thu: { open: "07:00", close: "20:00" },
  fri: { open: "07:00", close: "20:00" },
  sat: { open: "07:00", close: "20:00" },
  sun: { open: "07:00", close: "20:00" },
};

// Migrate old lottery data to new schedule format
function migrateLotteryAdmin(lottery: any) {
  if (lottery.schedule) return lottery;
  const closeTime = lottery.closeTime || lottery.drawTime || "20:00";
  return {
    ...lottery,
    schedule: {
      mon: { open: "07:00", close: closeTime },
      tue: { open: "07:00", close: closeTime },
      wed: { open: "07:00", close: closeTime },
      thu: { open: "07:00", close: closeTime },
      fri: { open: "07:00", close: closeTime },
      sat: { open: "07:00", close: closeTime },
      sun: { open: "07:00", close: closeTime },
    },
  };
}

function LoteriasSection() {
  const [msg, setMsg] = useState("");
  const [lotteries, setLotteries] = useState(() => {
    const saved = localStorage.getItem("loteria_loterias");
    const data = saved ? JSON.parse(saved) : [
      { id: 1, name: "Loteria Nacional Noche", drawTime: "20:55", active: true },
      { id: 2, name: "Loteria Nacional Tarde", drawTime: "14:55", active: true },
      { id: 3, name: "Leidsa", drawTime: "20:55", active: true },
      { id: 4, name: "Loteria Real", drawTime: "12:55", active: true },
      { id: 5, name: "Loteka", drawTime: "19:55", active: true },
    ];
    return data.map(migrateLotteryAdmin);
  });
  const [name, setName] = useState("");
  const [time, setTime] = useState("12:00");
  const [editingId, setEditingId] = useState<number | null>(null);

  const save = (data: any[]) => {
    localStorage.setItem("loteria_loterias", JSON.stringify(data));
    setLotteries(data);
  };

  const add = () => {
    if (!name) { setMsg("Ingrese nombre"); setTimeout(() => setMsg(""), 2000); return; }
    const newId = Math.max(0, ...lotteries.map((l: any) => l.id)) + 1;
    const sched = { ...DEFAULT_SCHEDULE };
    // Set close time from input
    Object.keys(sched).forEach((k) => { (sched as any)[k].close = time; });
    save([...lotteries, { id: newId, name, drawTime: time, closeTime: time, active: true, schedule: sched }]);
    setName(""); setMsg("Creada!"); setTimeout(() => setMsg(""), 2000);
  };

  const toggle = (id: number) => {
    save(lotteries.map((l: any) => l.id === id ? { ...l, active: !l.active } : l));
  };

  const remove = (id: number) => {
    if (confirm("Eliminar?")) save(lotteries.filter((l: any) => l.id !== id));
  };

  const updateSchedule = (id: number, day: string, field: "open" | "close", value: string) => {
    save(lotteries.map((l: any) => {
      if (l.id !== id) return l;
      return {
        ...l,
        schedule: {
          ...l.schedule,
          [day]: { ...l.schedule[day], [field]: value },
        },
      };
    }));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}
      <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm space-y-3">
        <h3 className="text-sm font-bold text-green-700">Nueva Loteria</h3>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nombre" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
        <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
        <p className="text-[10px] text-gray-500">Hora de cierre (lunes a domingo). Puedes editar por dia despues.</p>
        <button onClick={add} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700 flex items-center justify-center gap-2">
          <Plus size={16} /> Crear
        </button>
      </div>
      <div className="space-y-3">
        {lotteries.map((l: any) => (
          <div key={l.id} className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between p-3">
              <div>
                <p className="text-sm font-bold text-gray-900">{l.name}</p>
                <p className="text-[10px] text-gray-500">Sorteo: {l.drawTime}</p>
              </div>
              <div className="flex items-center gap-1.5">
                <button onClick={() => setEditingId(editingId === l.id ? null : l.id)} className={`px-2 py-1 rounded text-[10px] font-bold ${editingId === l.id ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-600"}`}>
                  Horario
                </button>
                <button onClick={() => toggle(l.id)} className={`px-2 py-1 rounded text-[10px] font-bold ${l.active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                  {l.active ? "Activa" : "Inactiva"}
                </button>
                <button onClick={() => remove(l.id)} className="p-1.5 rounded-lg hover:bg-red-50"><Trash2 size={16} className="text-red-500" /></button>
              </div>
            </div>
            {/* Schedule editor */}
            {editingId === l.id && l.schedule && (
              <div className="px-3 pb-3 pt-1 bg-green-50/50 border-t border-green-100">
                <p className="text-[10px] font-bold text-green-700 mb-2">Horario por dia (Apertura - Cierre)</p>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(DAY_LABELS).map(([day, label]) => (
                    <div key={day} className="flex items-center gap-1.5">
                      <span className="text-[10px] font-semibold w-6 text-gray-600">{label}</span>
                      <input
                        type="time"
                        value={l.schedule[day]?.open || "07:00"}
                        onChange={(e) => updateSchedule(l.id, day, "open", e.target.value)}
                        className="w-[70px] px-1 py-0.5 text-[10px] border border-green-200 rounded"
                      />
                      <span className="text-[10px] text-gray-400">-</span>
                      <input
                        type="time"
                        value={l.schedule[day]?.close || "20:00"}
                        onChange={(e) => updateSchedule(l.id, day, "close", e.target.value)}
                        className="w-[70px] px-1 py-0.5 text-[10px] border border-green-200 rounded"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── GRUPOS ────────────────────────────────────────────────────────
function GruposSection() {
  const [msg, setMsg] = useState("");
  const [name, setName] = useState("");
  const [selectedGroup, setSelectedGroup] = useState<any>(null);
  const [editGroupName, setEditGroupName] = useState("");
  const [showAddUser, setShowAddUser] = useState(false);
  const [editMember, setEditMember] = useState<any>(null);
  const [editMemberData, setEditMemberData] = useState({ name: "", username: "", password: "", phone: "", role: "user", credit: "", commission: "", active: true });
  const [creditModal, setCreditModal] = useState<any>(null);
  const [creditAmount, setCreditAmount] = useState("");
  const [creditAction, setCreditAction] = useState<"add" | "subtract">("add");

  // tRPC hooks for groups
  const trpcGroups = trpc.group.list.useQuery();
  const createGroupMut = trpc.group.create.useMutation({ 
    onSuccess: () => { trpcGroups.refetch(); showMsg("Grupo creado!"); },
    onError: (err) => { showMsg("Error: " + err.message); }
  });
  const updateGroupMut = trpc.group.update.useMutation({ 
    onSuccess: () => { trpcGroups.refetch(); showMsg("Grupo actualizado!"); },
    onError: (err) => { showMsg("Error: " + err.message); }
  });
  const deleteGroupMut = trpc.group.delete.useMutation({ 
    onSuccess: () => { trpcGroups.refetch(); showMsg("Grupo eliminado!"); },
    onError: (err) => { showMsg("Error: " + err.message); }
  });
  
  // tRPC hooks for users
  const trpcUsers = trpc.lotteryUser.list.useQuery();
  const updateUserMut = trpc.lotteryUser.update.useMutation({ onSuccess: () => { trpcUsers.refetch(); } });
  const updateCreditMut = trpc.lotteryUser.updateCredit.useMutation({ onSuccess: () => { trpcUsers.refetch(); } });

  const groups = trpcGroups.data || [];
  const allUsers = trpcUsers.data || [];
  const roleLabels: Record<string, string> = { admin: "Admin", supervisor: "Supervisor", collector: "Cobrador", user: "Vendedor" };

  const add = () => {
    if (!name) { setMsg("Ingrese un nombre"); setTimeout(() => setMsg(""), 2000); return; }
    createGroupMut.mutate({ name, maxSalesPerDay: "50000" }, {
      onSuccess: () => { setName(""); },
      onError: (err) => { showMsg("Error: " + err.message); }
    });
  };

  const updateGroupNameFn = () => {
    if (!editGroupName.trim() || !selectedGroup) return;
    updateGroupMut.mutate({ id: selectedGroup.id, name: editGroupName });
    setSelectedGroup({ ...selectedGroup, name: editGroupName });
    setMsg("Nombre actualizado!"); setTimeout(() => setMsg(""), 2000);
  };

  const removeUserFromGroup = (userId: number) => {
    if (!confirm("Quitar usuario del grupo?")) return;
    updateUserMut.mutate({ id: userId, groupId: null });
    setMsg("Usuario removido!"); setTimeout(() => setMsg(""), 2000);
  };

  const addUserToGroup = (userId: number) => {
    if (!selectedGroup) return;
    updateUserMut.mutate({ id: userId, groupId: selectedGroup.id });
    setMsg("Usuario agregado!"); setTimeout(() => setMsg(""), 2000);
  };

  const handleEditMember = () => {
    if (!editMember) return;
    const payload: any = { id: editMember.id };
    if (editMemberData.name !== editMember.name) payload.name = editMemberData.name;
    if (editMemberData.username !== editMember.username) payload.username = editMemberData.username;
    if (editMemberData.password) payload.password = editMemberData.password;
    if (editMemberData.phone !== (editMember.phone || "")) payload.phone = editMemberData.phone || null;
    if (editMemberData.role !== editMember.role) payload.role = editMemberData.role;
    if (editMemberData.credit !== String(editMember.credit)) payload.credit = editMemberData.credit;
    if (editMemberData.active !== !!editMember.active) payload.active = editMemberData.active;
    updateUserMut.mutate(payload);
    setEditMember(null);
    setMsg("Usuario actualizado!"); setTimeout(() => setMsg(""), 3000);
  };

  const handleCreditChange = () => {
    if (!creditModal || !creditAmount || Number(creditAmount) <= 0) { setMsg("Ingrese un monto valido"); setTimeout(() => setMsg(""), 2000); return; }
    const amount = Number(creditAmount);
    const currentCredit = Number(creditModal.credit) || 0;
    const newCredit = creditAction === "add" ? currentCredit + amount : Math.max(0, currentCredit - amount);
    updateCreditMut.mutate({ id: creditModal.id, credit: String(newCredit) });
    setCreditModal(null); setCreditAmount("");
    setMsg(`Credito ${creditAction === "add" ? "aumentado" : "reducido"} en $${formatMoney(amount)}!`);
    setTimeout(() => setMsg(""), 3000);
  };

  // ─── GROUP DETAIL VIEW ────────────────────────────────────────────
  if (selectedGroup) {
    const groupUsers = allUsers.filter((u: any) => u.groupId === selectedGroup.id);
    const availableUsers = allUsers.filter((u: any) => !u.groupId && u.role !== "admin");

    return (
      <div className="px-4 py-4 space-y-4">
        {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}
        {/* Back button */}
        <button onClick={() => setSelectedGroup(null)} className="flex items-center gap-1.5 text-sm text-green-700 font-bold">
          <ChevronLeft size={18} /> Volver a grupos
        </button>
        {/* Group info card */}
        <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm space-y-3">
          <h3 className="text-sm font-bold text-green-700">Informacion del Grupo</h3>
          <div className="flex gap-2">
            <input value={editGroupName} onChange={(e) => setEditGroupName(e.target.value)} className="flex-1 px-3 py-2 border border-green-200 rounded-lg text-sm font-bold" />
            <button onClick={updateGroupName} className="px-3 py-2 bg-green-600 text-white rounded-lg text-sm font-bold hover:bg-green-700"><Pencil size={14} /></button>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] px-2 py-1 bg-green-100 text-green-700 rounded-full font-bold">{groupUsers.length} usuario(s)</span>
            <span className="text-[10px] px-2 py-1 bg-blue-100 text-blue-700 rounded-full font-bold">ID: {selectedGroup.id}</span>
          </div>
        </div>

        {/* Members */}
        <div className="space-y-2">
          <h4 className="text-sm font-bold text-gray-900">Miembros del Grupo</h4>
          {groupUsers.length === 0 && <p className="text-xs text-gray-400 text-center py-4">Sin miembros. Agregue usuarios.</p>}
          {groupUsers.map((u: any) => (
            <div key={u.id} className="bg-white rounded-xl border border-gray-100 shadow-sm p-3">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-gray-900 truncate">{u.name} <span className="text-[10px] font-normal text-green-600">({u.bankNumber})</span></p>
                  <p className="text-[10px] text-gray-500">{u.username} | {roleLabels[u.role] || u.role} | ${formatMoney(u.credit)} | Com: {u.commission || 0}%</p>
                </div>
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${u.active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{u.active ? "Activo" : "Bloqueado"}</span>
              </div>
              <div className="flex gap-1.5 mt-2 flex-wrap">
                <button onClick={() => { setEditMember(u); setEditMemberData({ name: u.name, username: u.username, password: "", phone: u.phone || "", role: u.role, credit: String(u.credit), commission: String(u.commission || "0"), active: !!u.active }); }} className="flex-1 py-1.5 bg-green-50 text-green-700 rounded-lg text-[11px] font-bold hover:bg-green-100">Editar</button>
                <button onClick={() => { setCreditModal(u); setCreditAmount(""); setCreditAction("add"); }} className="flex-1 py-1.5 bg-yellow-50 text-yellow-700 rounded-lg text-[11px] font-bold hover:bg-yellow-100">Credito</button>
                <button onClick={() => removeUserFromGroup(u.id)} className="flex-1 py-1.5 bg-red-50 text-red-600 rounded-lg text-[11px] font-bold hover:bg-red-100">Quitar</button>
              </div>
            </div>
          ))}
        </div>

        {/* Add existing user */}
        <div className="space-y-2">
          {!showAddUser ? (
            <button onClick={() => setShowAddUser(true)} className="w-full py-2.5 bg-blue-600 text-white rounded-lg font-bold text-sm hover:bg-blue-700 flex items-center justify-center gap-2">
              <UserPlus size={16} /> Agregar Usuario Existente
            </button>
          ) : (
            <div className="bg-blue-50 rounded-xl border border-blue-200 p-3 space-y-2">
              <h4 className="text-sm font-bold text-blue-700">Usuarios sin grupo</h4>
              {availableUsers.length === 0 && <p className="text-xs text-gray-400">No hay usuarios disponibles.</p>}
              {availableUsers.map((u: any) => (
                <button key={u.id} onClick={() => { addUserToGroup(u.id); setShowAddUser(false); }} className="w-full flex items-center justify-between p-2 bg-white rounded-lg border border-blue-100 hover:border-blue-300 transition-all text-left">
                  <span className="text-sm font-medium text-gray-900">{u.name} <span className="text-[10px] text-gray-500">({u.username} - {roleLabels[u.role]})</span></span>
                  <UserPlus size={14} className="text-blue-600" />
                </button>
              ))}
              <button onClick={() => setShowAddUser(false)} className="w-full py-2 bg-gray-100 text-gray-600 rounded-lg text-xs font-bold">Cancelar</button>
            </div>
          )}
        </div>

        {/* Edit member modal */}
        {editMember && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm max-h-[85%] flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-gray-100"><h3 className="font-bold text-lg text-gray-900">Editar Usuario</h3><button onClick={() => setEditMember(null)} className="p-1.5 hover:bg-gray-100 rounded-lg"><X size={20} className="text-gray-500" /></button></div>
              <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
                <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Nombre</label><input value={editMemberData.name} onChange={(e) => setEditMemberData({ ...editMemberData, name: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
                <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Usuario</label><input value={editMemberData.username} onChange={(e) => setEditMemberData({ ...editMemberData, username: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
                <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Contrasena (dejar vacio para no cambiar)</label><input type="password" value={editMemberData.password} onChange={(e) => setEditMemberData({ ...editMemberData, password: e.target.value })} placeholder="Nueva contrasena" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
                <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Telefono</label><input value={editMemberData.phone} onChange={(e) => setEditMemberData({ ...editMemberData, phone: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
                <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Rol</label><select value={editMemberData.role} onChange={(e) => setEditMemberData({ ...editMemberData, role: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm"><option value="user">Vendedor</option><option value="collector">Cobrador</option><option value="supervisor">Supervisor</option></select></div>
                <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Credito</label><input type="number" value={editMemberData.credit} onChange={(e) => setEditMemberData({ ...editMemberData, credit: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
                <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Comision %</label><input type="number" value={editMemberData.commission} onChange={(e) => setEditMemberData({ ...editMemberData, commission: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={editMemberData.active} onChange={(e) => setEditMemberData({ ...editMemberData, active: e.target.checked })} className="w-4 h-4 accent-green-600" /><span className={editMemberData.active ? "text-green-700 font-medium" : "text-gray-500"}>{editMemberData.active ? "Activo" : "Bloqueado"}</span></label>
              </div>
              <div className="p-3 border-t border-gray-100"><button onClick={handleEditMember} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700">Guardar Cambios</button></div>
            </div>
          </div>
        )}

        {/* Credit modal */}
        {creditModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-5">
              <div className="text-center mb-4">
                <div className="w-14 h-14 mx-auto bg-yellow-100 rounded-full flex items-center justify-center mb-2"><Wallet size={28} className="text-yellow-600" /></div>
                <h3 className="font-bold text-lg text-gray-900">Gestionar Credito</h3>
                <p className="text-sm text-gray-500">{creditModal.name}</p>
                <p className="text-sm font-bold text-green-700 mt-1">Credito actual: ${formatMoney(creditModal.credit)}</p>
              </div>
              <div className="flex gap-2 mb-3">
                <button onClick={() => setCreditAction("add")} className={`flex-1 py-2 rounded-lg text-sm font-bold ${creditAction === "add" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-600"}`}>Agregar</button>
                <button onClick={() => setCreditAction("subtract")} className={`flex-1 py-2 rounded-lg text-sm font-bold ${creditAction === "subtract" ? "bg-red-600 text-white" : "bg-gray-100 text-gray-600"}`}>Reducir</button>
              </div>
              <input type="number" value={creditAmount} onChange={(e) => setCreditAmount(e.target.value)} placeholder="Monto" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm font-bold text-center text-lg mb-3" autoFocus />
              <div className="flex gap-2">
                <button onClick={() => setCreditModal(null)} className="flex-1 py-2.5 rounded-xl bg-gray-100 text-gray-700 font-bold text-sm hover:bg-gray-200">Cancelar</button>
                <button onClick={handleCreditChange} className={`flex-1 py-2.5 rounded-xl font-bold text-sm text-white ${creditAction === "add" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}`}>{creditAction === "add" ? "Agregar" : "Reducir"}</button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ─── GROUP LIST VIEW ──────────────────────────────────────────────
  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}
      <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm space-y-3">
        <h3 className="text-sm font-bold text-green-700">Nuevo Grupo</h3>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nombre" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
        <button onClick={add} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700 flex items-center justify-center gap-2">
          <Plus size={16} /> Crear Grupo
        </button>
      </div>
      <div className="space-y-2">
        {groups.map((g: any) => {
          const memberCount = allUsers.filter((u: any) => u.groupId === g.id).length;
          return (
            <div key={g.id} className="flex items-center gap-2">
              <button onClick={() => { setSelectedGroup(g); setEditGroupName(g.name); setShowAddUser(false); }} className="flex-1 flex items-center justify-between p-3 bg-white rounded-xl border border-gray-100 shadow-sm hover:border-green-300 transition-all text-left">
                <div>
                  <p className="text-sm font-bold text-gray-900">{g.name}</p>
                  <p className="text-[10px] text-gray-500">{memberCount} miembro(s) | Toca para ver detalles</p>
                </div>
                <ChevronRight size={16} className="text-gray-300" />
              </button>
              <button onClick={() => { if (confirm(`Eliminar grupo "${g.name}"?`)) deleteGroupMut.mutate({ id: g.id }); }} className="p-3 bg-white rounded-xl border border-red-100 shadow-sm hover:bg-red-50 transition-all shrink-0">
                <Trash2 size={16} className="text-red-500" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── USUARIOS ──────────────────────────────────────────────────────
function UsuariosSection() {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: "", username: "", password: "", phone: "", role: "user" as any, groupId: "", credit: "5000", commission: "10" });
  const [msg, setMsg] = useState("");
  const [search, setSearch] = useState("");
  const [viewUser, setViewUser] = useState<any>(null);
  const [editUser, setEditUser] = useState<any>(null);
  const [editData, setEditData] = useState({ name: "", username: "", password: "", phone: "", role: "user", groupId: "", credit: "5000", commission: "10", active: true });
  const [creditModal, setCreditModal] = useState<any>(null);
  const [creditAmount, setCreditAmount] = useState("");
  const [creditAction, setCreditAction] = useState<"add" | "subtract">("add");
  const [deleteUser, setDeleteUser] = useState<any>(null);
  const trpcUsers = trpc.lotteryUser.list.useQuery();
  const createUserMut = trpc.lotteryUser.create.useMutation({ 
    onSuccess: () => { trpcUsers.refetch(); showMsg("Usuario creado!"); },
    onError: (err) => { showMsg("Error: " + err.message); }
  });
  const updateUserMut = trpc.lotteryUser.update.useMutation({ 
    onSuccess: () => { trpcUsers.refetch(); showMsg("Usuario actualizado!"); },
    onError: (err) => { showMsg("Error: " + err.message); }
  });
  const deleteUserMut = trpc.lotteryUser.delete.useMutation({ 
    onSuccess: () => { trpcUsers.refetch(); showMsg("Usuario eliminado!"); },
    onError: (err) => { showMsg("Error: " + err.message); }
  });
  const updateCreditMut = trpc.lotteryUser.updateCredit.useMutation({ 
    onSuccess: () => { trpcUsers.refetch(); },
    onError: (err) => { showMsg("Error: " + err.message); }
  });

  const users = trpcUsers.data || [];
  const refresh = () => trpcUsers.refetch();
  const showMsg = (m: string) => { setMsg(m); setTimeout(() => setMsg(""), 3000); };

  const handleCreate = () => {
    if (!formData.name || !formData.username || !formData.password) { showMsg("Complete los campos obligatorios"); return; }
    if (formData.password.length < 4) { showMsg("La contrasena debe tener al menos 4 caracteres"); return; }
    createUserMut.mutate({
      bankNumber: getNextBankNumber(),
      name: formData.name,
      username: formData.username,
      password: formData.password,
      phone: formData.phone || undefined,
      role: formData.role as any,
      groupId: formData.groupId ? Number(formData.groupId) : undefined,
      credit: formData.credit,
      commission: formData.commission,
    }, {
      onSuccess: () => {
        setShowForm(false);
        setFormData({ name: "", username: "", password: "", phone: "", role: "user", groupId: "", credit: "5000", commission: "10" });
        showMsg("Usuario creado en el servidor!");
      },
      onError: (err) => {
        showMsg("Error al crear: " + err.message);
      }
    });
  };

  const handleEditSave = () => {
    if (!editUser) return;
    const payload: any = { id: editUser.id };
    if (editData.name !== editUser.name) payload.name = editData.name;
    if (editData.username !== editUser.username) payload.username = editData.username;
    if (editData.password) payload.password = editData.password;
    if (editData.phone !== (editUser.phone || "")) payload.phone = editData.phone || null;
    if (editData.role !== editUser.role) payload.role = editData.role;
    if (editData.groupId !== (editUser.groupId || "")) payload.groupId = editData.groupId ? Number(editData.groupId) : null;
    if (editData.credit !== String(editUser.credit)) payload.credit = editData.credit;
    if (editData.active !== !!editUser.active) payload.active = editData.active;
    updateUserMut.mutate(payload);
    setEditUser(null); showMsg("Usuario actualizado en el servidor!");
  };

  const handleCreditChange = () => {
    if (!creditModal || !creditAmount || Number(creditAmount) <= 0) { showMsg("Ingrese un monto valido"); return; }
    const amount = Number(creditAmount);
    const currentCredit = Number(creditModal.credit) || 0;
    const newCredit = creditAction === "add" ? currentCredit + amount : Math.max(0, currentCredit - amount);
    updateCreditMut.mutate({ id: creditModal.id, credit: String(newCredit) });
    setCreditModal(null);
    setCreditAmount("");
    showMsg(`Credito ${creditAction === "add" ? "aumentado" : "reducido"} en $${formatMoney(amount)}!`);
  };

  const handleDelete = () => {
    if (!deleteUser) return;
    deleteUserMut.mutate({ id: deleteUser.id });
    setDeleteUser(null); showMsg("Usuario eliminado del servidor!");
  };

  const openEdit = (u: any) => {
    setEditData({ name: u.name, username: u.username, password: "", phone: u.phone || "", role: u.role, groupId: u.groupId || "", credit: String(u.credit), commission: String(u.commission || "0"), active: !!u.active });
    setEditUser(u);
  };

  const roleLabels: Record<string, string> = { admin: "Administrador", supervisor: "Supervisor", collector: "Cobrador", user: "Vendedor" };
  const groups = JSON.parse(localStorage.getItem("loteria_groups") || "[{\"id\":1,\"name\":\"Grupo Principal\"}]");
  const filtered = search ? users.filter((u: any) => u.name.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase())) : users;

  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}
      <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por nombre o usuario..." className="w-full px-3 py-2.5 border border-green-200 rounded-lg text-sm focus:outline-none focus:border-green-500" />
      <button onClick={() => setShowForm(!showForm)} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700 flex items-center justify-center gap-2">
        <Plus size={16} /> {showForm ? "Cancelar" : "Crear Usuario"}
      </button>
      {showForm && (
        <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm space-y-3">
          <h4 className="text-sm font-bold text-green-700">Nuevo Usuario</h4>
          <input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Nombre completo *" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
          <input value={formData.username} onChange={(e) => setFormData({ ...formData, username: e.target.value })} placeholder="Usuario *" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" autoCapitalize="none" />
          <input type="password" value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })} placeholder="Contrasena *" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
          <input value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} placeholder="Telefono" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
          <select value={formData.role} onChange={(e) => setFormData({ ...formData, role: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm">
            <option value="user">Vendedor</option><option value="collector">Cobrador</option><option value="supervisor">Supervisor</option><option value="admin">Administrador</option>
          </select>
          <select value={formData.groupId} onChange={(e) => setFormData({ ...formData, groupId: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm">
            <option value="">Sin grupo</option>{groups.map((g: any) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
          <input type="number" value={formData.credit} onChange={(e) => setFormData({ ...formData, credit: e.target.value })} placeholder="Credito inicial" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
          <input type="number" value={formData.commission} onChange={(e) => setFormData({ ...formData, commission: e.target.value })} placeholder="Comision % (ej: 10)" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
          <button onClick={handleCreate} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700">Guardar Usuario</button>
        </div>
      )}
      <div className="space-y-2">
        {filtered.length > 0 ? filtered.map((u: any) => (
          <div key={u.id} className="p-3 bg-white rounded-xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold text-gray-900 truncate">{u.name} <span className="text-[10px] font-normal text-green-600">({u.bankNumber})</span></p>
                <p className="text-[10px] text-gray-500">{u.username} | {roleLabels[u.role] || u.role} | ${formatMoney(u.credit)} | Com: {u.commission || 0}%</p>
              </div>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${u.active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{u.active ? "Activo" : "Bloqueado"}</span>
            </div>
            <div className="flex gap-1.5 mt-2 flex-wrap">
              <button onClick={() => setViewUser(u)} className="flex-1 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-[11px] font-bold hover:bg-blue-100">Ver Info</button>
              <button onClick={() => openEdit(u)} className="flex-1 py-1.5 bg-green-50 text-green-700 rounded-lg text-[11px] font-bold hover:bg-green-100">Editar</button>
              <button onClick={() => { setCreditModal(u); setCreditAmount(""); setCreditAction("add"); }} className="flex-1 py-1.5 bg-yellow-50 text-yellow-700 rounded-lg text-[11px] font-bold hover:bg-yellow-100">Credito</button>
              <button onClick={() => setDeleteUser(u)} className="flex-1 py-1.5 bg-red-50 text-red-600 rounded-lg text-[11px] font-bold hover:bg-red-100">Eliminar</button>
            </div>
          </div>
        )) : <p className="text-sm text-gray-400 text-center py-4">No se encontraron usuarios</p>}
      </div>
      {viewUser && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm max-h-[85%] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-100"><h3 className="font-bold text-lg text-gray-900">Informacion del Usuario</h3><button onClick={() => setViewUser(null)} className="p-1.5 hover:bg-gray-100 rounded-lg"><X size={20} className="text-gray-500" /></button></div>
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
              <div className="text-center p-4 bg-green-50 rounded-xl">
                <div className="w-16 h-16 mx-auto bg-green-600 rounded-full flex items-center justify-center text-white text-xl font-bold mb-2">{viewUser.name.charAt(0).toUpperCase()}</div>
                <p className="font-bold text-gray-900">{viewUser.name}</p><p className="text-xs text-green-600">{viewUser.bankNumber}</p>
              </div>
              {[["Nombre", viewUser.name], ["Usuario", viewUser.username], ["Telefono", viewUser.phone || "No registrado"], ["Rol", roleLabels[viewUser.role] || viewUser.role], ["Banca", viewUser.bankNumber], ["Credito", `$${formatMoney(viewUser.credit)}`], ["Estado", viewUser.active ? "Activo" : "Bloqueado"]].map(([label, value]) => (
                <div key={label} className="flex justify-between py-2 border-b border-gray-50"><span className="text-xs text-gray-500">{label}</span><span className="text-sm font-medium text-gray-900">{value}</span></div>
              ))}
            </div>
            <div className="p-3 border-t border-gray-100"><button onClick={() => { setViewUser(null); openEdit(viewUser); }} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700">Editar Usuario</button></div>
          </div>
        </div>
      )}
      {editUser && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm max-h-[85%] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-100"><h3 className="font-bold text-lg text-gray-900">Editar Usuario</h3><button onClick={() => setEditUser(null)} className="p-1.5 hover:bg-gray-100 rounded-lg"><X size={20} className="text-gray-500" /></button></div>
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
              {[["Nombre", "name"], ["Usuario", "username"]].map(([label, field]) => (
                <div key={field}><label className="text-[10px] font-medium text-gray-600 mb-1 block">{label}</label><input value={(editData as any)[field]} onChange={(e) => setEditData({ ...editData, [field]: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
              ))}
              <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Contrasena (dejar vacio para no cambiar)</label><input type="password" value={editData.password} onChange={(e) => setEditData({ ...editData, password: e.target.value })} placeholder="Nueva contrasena" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
              <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Telefono</label><input value={editData.phone} onChange={(e) => setEditData({ ...editData, phone: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
              <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Rol</label><select value={editData.role} onChange={(e) => setEditData({ ...editData, role: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm"><option value="user">Vendedor</option><option value="collector">Cobrador</option><option value="supervisor">Supervisor</option><option value="admin">Administrador</option></select></div>
              <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Grupo</label><select value={editData.groupId} onChange={(e) => setEditData({ ...editData, groupId: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm"><option value="">Sin grupo</option>{groups.map((g: any) => <option key={g.id} value={g.id}>{g.name}</option>)}</select></div>
              <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Credito</label><input type="number" value={editData.credit} onChange={(e) => setEditData({ ...editData, credit: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
              <div><label className="text-[10px] font-medium text-gray-600 mb-1 block">Comision %</label><input type="number" value={editData.commission} onChange={(e) => setEditData({ ...editData, commission: e.target.value })} placeholder="Ej: 10" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" /></div>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={editData.active} onChange={(e) => setEditData({ ...editData, active: e.target.checked })} className="w-4 h-4 accent-green-600" /><span className={editData.active ? "text-green-700 font-medium" : "text-gray-500"}>{editData.active ? "Usuario Activo" : "Usuario Bloqueado"}</span></label>
            </div>
            <div className="p-3 border-t border-gray-100"><button onClick={handleEditSave} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700">Guardar Cambios</button></div>
          </div>
        </div>
      )}
      {deleteUser && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-5">
            <div className="w-12 h-12 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-3"><Trash2 size={24} className="text-red-600" /></div>
            <h3 className="font-bold text-lg text-gray-900 text-center mb-1">Eliminar Usuario</h3>
            <p className="text-sm text-gray-500 text-center mb-4">Eliminar a <strong>{deleteUser.name}</strong> ({deleteUser.bankNumber})? Esta accion no se puede deshacer.</p>
            <div className="flex gap-2">
              <button onClick={() => setDeleteUser(null)} className="flex-1 py-3 rounded-xl bg-gray-100 text-gray-700 font-bold text-sm hover:bg-gray-200">Cancelar</button>
              <button onClick={handleDelete} className="flex-1 py-3 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700">Eliminar</button>
            </div>
          </div>
        </div>
      )}
      {/* Credit Modal */}
      {creditModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-5">
            <div className="text-center mb-4">
              <div className="w-14 h-14 mx-auto bg-yellow-100 rounded-full flex items-center justify-center mb-2"><Wallet size={28} className="text-yellow-600" /></div>
              <h3 className="font-bold text-lg text-gray-900">Gestionar Credito</h3>
              <p className="text-sm text-gray-500">{creditModal.name} ({creditModal.bankNumber})</p>
              <p className="text-sm font-bold text-green-700 mt-1">Credito actual: ${formatMoney(creditModal.credit)}</p>
            </div>
            <div className="flex gap-2 mb-3">
              <button onClick={() => setCreditAction("add")} className={`flex-1 py-2 rounded-lg text-sm font-bold ${creditAction === "add" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-600"}`}>Agregar</button>
              <button onClick={() => setCreditAction("subtract")} className={`flex-1 py-2 rounded-lg text-sm font-bold ${creditAction === "subtract" ? "bg-red-600 text-white" : "bg-gray-100 text-gray-600"}`}>Reducir</button>
            </div>
            <input type="number" value={creditAmount} onChange={(e) => setCreditAmount(e.target.value)} placeholder="Monto" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm font-bold text-center text-lg mb-3" autoFocus />
            <div className="flex gap-2">
              <button onClick={() => setCreditModal(null)} className="flex-1 py-2.5 rounded-xl bg-gray-100 text-gray-700 font-bold text-sm hover:bg-gray-200">Cancelar</button>
              <button onClick={handleCreditChange} className={`flex-1 py-2.5 rounded-xl font-bold text-sm text-white ${creditAction === "add" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}`}>{creditAction === "add" ? "Agregar" : "Reducir"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── PREMIOS ───────────────────────────────────────────────────────
function PremiosSection() {
  const [msg, setMsg] = useState("");
  const [prizes, setPrizes] = useState(() => {
    const saved = localStorage.getItem("loteria_prizes");
    return saved ? JSON.parse(saved) : [
      { id: 1, playType: "directo", firstPrizeMultiplier: "50", secondPrizeMultiplier: "15", thirdPrizeMultiplier: "10", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "0", description: "1er=50x, 2do=15x, 3ro=10x" },
      { id: 2, playType: "pale", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "25", paleFirstThirdMultiplier: "20", paleSecondThirdMultiplier: "15", fixedMultiplier: "0", description: "1+2=25x, 1+3=20x, 2+3=15x" },
      { id: 3, playType: "terna", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "500", description: "3 cifras = 500x" },
      { id: 4, playType: "cuatrena", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "4000", description: "4 cifras = 4,000x" },
      { id: 5, playType: "tripleta", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "10000", description: "Tripleta = 10,000x" },
    ];
  });

  const save = (data: any[]) => { localStorage.setItem("loteria_prizes", JSON.stringify(data)); setPrizes(data); };
  const update = (id: number, field: string, value: string) => {
    save(prizes.map((p: any) => p.id === id ? { ...p, [field]: value } : p));
    setMsg("Premio actualizado!"); setTimeout(() => setMsg(""), 2000);
  };

  const typeLabels: Record<string, string> = { directo: "Directo", pale: "Pale", terna: "Terna (3 cifras)", cuatrena: "Cuatrena (4 cifras)", tripleta: "Tripleta" };

  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}
      <p className="text-sm text-gray-600">Configure cuanto paga cada tipo de jugada por cada euro jugado.</p>
      {prizes.map((prize: any) => (
        <div key={prize.id} className="bg-white rounded-xl border border-green-100 p-4 shadow-sm space-y-3">
          <h3 className="text-sm font-bold text-green-700">{typeLabels[prize.playType] || prize.playType}</h3>
          <p className="text-[10px] text-gray-500">{prize.description}</p>
          {prize.playType === "directo" && (
            <div className="grid grid-cols-3 gap-2">
              {[["1er Premio (x)", "firstPrizeMultiplier"], ["2do Premio (x)", "secondPrizeMultiplier"], ["3er Premio (x)", "thirdPrizeMultiplier"]].map(([label, field]) => (
                <div key={field}><label className="text-[10px] font-medium text-gray-700 block mb-1">{label}</label><input type="number" step="0.01" defaultValue={prize[field]} onBlur={(e) => update(prize.id, field, e.target.value)} className="w-full px-2 py-1.5 border border-green-200 rounded-lg text-sm text-center font-bold" /></div>
              ))}
            </div>
          )}
          {prize.playType === "pale" && (
            <div className="grid grid-cols-3 gap-2">
              {[["1er + 2do (x)", "paleFirstSecondMultiplier"], ["1er + 3ro (x)", "paleFirstThirdMultiplier"], ["2do + 3ro (x)", "paleSecondThirdMultiplier"]].map(([label, field]) => (
                <div key={field}><label className="text-[10px] font-medium text-gray-700 block mb-1">{label}</label><input type="number" step="0.01" defaultValue={prize[field]} onBlur={(e) => update(prize.id, field, e.target.value)} className="w-full px-2 py-1.5 border border-green-200 rounded-lg text-sm text-center font-bold" /></div>
              ))}
            </div>
          )}
          {["terna", "cuatrena", "tripleta"].includes(prize.playType) && (
            <div><label className="text-[10px] font-medium text-gray-700 block mb-1">Por cada euro jugado (x)</label><input type="number" step="0.01" defaultValue={prize.fixedMultiplier} onBlur={(e) => update(prize.id, "fixedMultiplier", e.target.value)} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm font-bold" /></div>
          )}
        </div>
      ))}
      <div className="bg-yellow-50 rounded-xl border border-yellow-200 p-4">
        <h4 className="text-sm font-bold text-yellow-800 mb-2">Resumen de Premios</h4>
        <div className="space-y-1 text-xs text-yellow-700">
          {prizes.map((p: any) => (
            <div key={p.id} className="flex justify-between"><span className="font-medium">{typeLabels[p.playType]}</span><span>{p.playType === "directo" ? `1ro=${p.firstPrizeMultiplier}x, 2do=${p.secondPrizeMultiplier}x, 3ro=${p.thirdPrizeMultiplier}x` : p.playType === "pale" ? `1+2=${p.paleFirstSecondMultiplier}x, 1+3=${p.paleFirstThirdMultiplier}x, 2+3=${p.paleSecondThirdMultiplier}x` : `${p.fixedMultiplier}x`}</span></div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── GANADORES ─────────────────────────────────────────────────────
function GanadoresSection() {
  const [msg, setMsg] = useState("");
  const [winners, setWinners] = useState(() => {
    const saved = localStorage.getItem("loteria_winners");
    return saved ? JSON.parse(saved) : [];
  });
  const [date, setDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [lottery, setLottery] = useState("");
  const [prizes, setPrizes] = useState({ first: "", second: "", third: "" });

  const lotteries = JSON.parse(localStorage.getItem("loteria_loterias") || "[]").filter((l: any) => l.active);
  const save = (data: any[]) => { localStorage.setItem("loteria_winners", JSON.stringify(data)); setWinners(data); };

  const handleSave = () => {
    if (!lottery || !prizes.first || !prizes.second || !prizes.third) { setMsg("Complete todos los campos"); setTimeout(() => setMsg(""), 3000); return; }
    const newId = Math.max(0, ...winners.map((w: any) => w.id)) + 1;
    save([...winners, { id: newId, lotteryId: Number(lottery), drawDate: date.replace(/-/g, ""), firstPrize: prizes.first, secondPrize: prizes.second, thirdPrize: prizes.third }]);
    setPrizes({ first: "", second: "", third: "" }); setMsg("Guardado!"); setTimeout(() => setMsg(""), 2000);
  };

  const filtered = winners.filter((w: any) => {
    const d = date.replace(/-/g, "");
    return (!lottery || w.lotteryId === Number(lottery)) && w.drawDate === d;
  });

  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}
      <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm space-y-3">
        <h3 className="text-sm font-bold text-green-700">Registrar Numeros</h3>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
        <select value={lottery} onChange={(e) => setLottery(e.target.value)} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm"><option value="">Seleccionar loteria...</option>{lotteries.map((l: any) => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
        <div className="grid grid-cols-3 gap-2">
          {[["1er", "first"], ["2do", "second"], ["3er", "third"]].map(([label, field]) => (
            <div key={field}><label className="text-[10px] font-medium text-gray-700 block mb-1">{label}</label><input value={(prizes as any)[field]} onChange={(e) => setPrizes({ ...prizes, [field]: e.target.value })} placeholder={label} maxLength={6} className="w-full px-2 py-2 border border-green-200 rounded-lg text-sm text-center font-bold" /></div>
          ))}
        </div>
        <button onClick={handleSave} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700">Guardar</button>
      </div>
      <div className="space-y-2">
        {filtered.map((w: any) => {
          const lot = lotteries.find((l: any) => l.id === w.lotteryId);
          return (
            <div key={w.id} className="bg-white rounded-xl border border-gray-100 p-3 shadow-sm">
              <p className="text-sm font-bold text-green-700">{lot?.name || `Loteria #${w.lotteryId}`}</p>
              <div className="flex gap-2 mt-2">
                <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs font-bold">{w.firstPrize}</span>
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-bold">{w.secondPrize}</span>
                <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs font-bold">{w.thirdPrize}</span>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && <p className="text-sm text-gray-400 text-center py-4">Sin resultados para esta fecha</p>}
      </div>
    </div>
  );
}

// ─── ANULAR ────────────────────────────────────────────────────────
function AnularSection() {
  const [search, setSearch] = useState("");
  const [filterUser, setFilterUser] = useState("");
  const [tickets, setTickets] = useState(() => {
    const saved = localStorage.getItem("loteria_tickets");
    return saved ? JSON.parse(saved) : [];
  });
  const [msg, setMsg] = useState("");

  const save = (data: any[]) => { localStorage.setItem("loteria_tickets", JSON.stringify(data)); setTickets(data); };
  const users = JSON.parse(localStorage.getItem("loteria_users") || "[]");

  const filtered = tickets.filter((t: any) => {
    const matchCode = t.code.toLowerCase().includes(search.toLowerCase());
    const matchUser = !filterUser || t.userId === Number(filterUser);
    return matchCode && matchUser && t.status === "active";
  });

  const annulTicket = (ticket: any) => {
    if (!confirm(`Anular ticket ${ticket.code}? El vendedor recuperara su credito.`)) return;
    // Recover credit to the seller
    const netDeduction = Number(ticket.netDeduction) || 0;
    if (netDeduction > 0) {
      addCredit(ticket.userId, netDeduction);
    }
    save(tickets.map((tk: any) => tk.id === ticket.id ? { ...tk, status: "cancelled" } : tk));
    // Log annul
    const commissionAmount = Number(ticket.total) * (Number(ticket.commission || 0) / 100);
    logAudit({
      type: "ticket_annul",
      userId: ticket.userId,
      userName: ticket.seller,
      groupId: ticket.groupId || null,
      amount: Number(ticket.total),
      description: `Ticket anulado por admin: ${ticket.code} | Credito recuperado: $${formatMoney(netDeduction)} | Comision perdida: $${formatMoney(commissionAmount)}`,
      ticketCode: ticket.code,
    });
    setMsg(`Ticket anulado! Credito de $${formatMoney(netDeduction)} recuperado al vendedor.`); setTimeout(() => setMsg(""), 3000);
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}

      <p className="text-sm text-gray-600">Como administrador, puedes anular tickets de cualquier usuario. Los tickets anulados quedan registrados para auditoria.</p>

      {/* Filters */}
      <div className="space-y-2">
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por codigo..." className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm focus:outline-none focus:border-green-500" />
        <select value={filterUser} onChange={(e) => setFilterUser(e.target.value)} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm">
          <option value="">Todos los usuarios</option>
          {users.map((u: any) => <option key={u.id} value={u.id}>{u.name} ({u.bankNumber})</option>)}
        </select>
      </div>

      {/* Stats */}
      <div className="bg-green-50 rounded-lg p-3 flex items-center justify-between">
        <span className="text-sm text-green-800 font-medium">{filtered.length} ticket(s) activo(s)</span>
        <span className="text-sm text-green-700 font-bold">${formatMoney(filtered.reduce((sum: number, t: any) => sum + Number(t.total), 0))}</span>
      </div>

      {/* Tickets List */}
      <div className="space-y-2">
        {filtered.length > 0 ? filtered.sort((a: any, b: any) => b.id - a.id).map((t: any) => {
          const seller = users.find((u: any) => u.id === t.userId);
          return (
            <div key={t.id} className="p-3 bg-white rounded-xl border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-gray-900">{t.code}</p>
                  <p className="text-[10px] text-gray-500">{t.date} {t.time} | {t.lottery}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-green-700">${formatMoney(t.total)}</p>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-green-100 text-green-700 font-medium">{t.status}</span>
                </div>
              </div>
              <div className="flex items-center justify-between bg-gray-50 rounded-lg p-2 mb-2">
                <span className="text-xs text-gray-600">Vendedor: <strong className="text-gray-900">{seller?.name || "Desconocido"}</strong></span>
                <span className="text-xs text-gray-500">{seller?.bankNumber || ""}</span>
              </div>
              <div className="flex gap-1.5">
                <button onClick={() => annulTicket(t)} className="w-full py-2 bg-red-100 text-red-600 rounded-lg text-xs font-bold hover:bg-red-200 flex items-center justify-center gap-1"><Ban size={12} /> Anular Ticket</button>
              </div>
            </div>
          );
        }) : <p className="text-sm text-gray-400 text-center py-4">No hay tickets activos</p>}
      </div>
    </div>
  );
}

// ─── REPORTES ──────────────────────────────────────────────────────
function ReportesGrupoSection() {
  return (
    <div className="px-4 py-4 space-y-4">
      <p className="text-sm text-gray-600">Reportes de ventas por grupo.</p>
      <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm">
        <p className="text-sm text-gray-500 text-center py-4">Funcion disponible proximamente</p>
      </div>
    </div>
  );
}

// ─── CONFIG ────────────────────────────────────────────────────────
function ConfigSection() {
  const [msg, setMsg] = useState("");
  const [config, setConfig] = useState(() => {
    const saved = localStorage.getItem("loteria_config");
    return saved ? JSON.parse(saved) : { maxBetAmount: "" };
  });

  const saveConfig = (newConfig: any) => {
    localStorage.setItem("loteria_config", JSON.stringify(newConfig));
    setConfig(newConfig);
    setMsg("Configuracion guardada!");
    setTimeout(() => setMsg(""), 3000);
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}
      <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm">
        <h3 className="text-sm font-bold text-green-700 mb-3">Limite por Jugada</h3>
        <p className="text-xs text-gray-500 mb-2">Monto maximo permitido por jugada individual. Dejar vacio o 0 para sin limite.</p>
        <div className="flex gap-2">
          <input type="number" value={config.maxBetAmount} onChange={(e) => saveConfig({ ...config, maxBetAmount: e.target.value })} placeholder="Ej: 1000" className="flex-1 px-3 py-2 border border-green-200 rounded-lg text-sm font-bold" />
          <button onClick={() => saveConfig({ ...config, maxBetAmount: "" })} className="px-3 py-2 bg-gray-100 text-gray-600 rounded-lg text-sm font-bold hover:bg-gray-200">Quitar</button>
        </div>
        {config.maxBetAmount && Number(config.maxBetAmount) > 0 && (
          <p className="text-xs text-green-600 font-bold mt-2">Limite activo: ${formatMoney(config.maxBetAmount)} por jugada</p>
        )}
      </div>
      <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm">
        <h3 className="text-sm font-bold text-green-700 mb-3">Informacion del Sistema</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between py-2 border-b border-gray-50"><span className="text-gray-600">Version</span><span className="font-medium">1.0.0</span></div>
          <div className="flex justify-between py-2 border-b border-gray-50"><span className="text-gray-600">Plataforma</span><span className="font-medium">Web / Android</span></div>
          <div className="flex justify-between py-2 border-b border-gray-50"><span className="text-gray-600">Modo</span><span className="font-medium text-green-600">Offline (localStorage)</span></div>
        </div>
      </div>
      <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm">
        <h3 className="text-sm font-bold text-green-700 mb-3">Datos</h3>
        <button onClick={() => { localStorage.removeItem("loteria_draft"); setMsg("Borrador limpiado!"); setTimeout(() => setMsg(""), 3000); }} className="w-full py-2.5 bg-orange-100 text-orange-700 rounded-lg font-bold text-sm hover:bg-orange-200 mb-2">Limpiar Borrador</button>
        <button onClick={() => { if (confirm("Borrar TODOS los datos?")) { localStorage.clear(); setMsg("Todos los datos borrados!"); setTimeout(() => setMsg(""), 3000); } }} className="w-full py-2.5 bg-red-100 text-red-700 rounded-lg font-bold text-sm hover:bg-red-200">Borrar Todo</button>
      </div>
      <div className="bg-yellow-50 rounded-xl border border-yellow-200 p-4"><p className="text-xs text-yellow-800">Banca Victoria v1.0 - Sistema de gestion de loteria. Funciona completamente offline.</p></div>
    </div>
  );
}

// ─── LIMITES ───────────────────────────────────────────────────────
interface LimitEntry {
  id: number;
  type: "global" | "user";
  userId: number | null;
  lotteryId: number | null;
  playType: string | null;
  maxAmount: number;
  blockedNumbers: string[];
  active: boolean;
}

const PLAY_TYPES: { value: string; label: string }[] = [
  { value: "directo", label: "Directo" },
  { value: "pale", label: "Pale" },
  { value: "terna", label: "3 Cifras" },
  { value: "cuatrena", label: "4 Cifras" },
  { value: "tripleta", label: "Tripleta" },
];

function LimitesSection() {
  const [msg, setMsg] = useState("");
  const showMsg = (m: string) => { setMsg(m); setTimeout(() => setMsg(""), 3000); };

  const [limits, setLimits] = useState<LimitEntry[]>(() => {
    const saved = localStorage.getItem("loteria_limits");
    return saved ? JSON.parse(saved) : [];
  });

  const allUsers = localGetUsers();
  const allLotteries = JSON.parse(localStorage.getItem("loteria_loterias") || "[]");

  const saveLimits = (data: LimitEntry[]) => {
    localStorage.setItem("loteria_limits", JSON.stringify(data));
    setLimits(data);
  };

  // Form state
  const [form, setForm] = useState({
    type: "global" as "global" | "user",
    userId: "",
    lotteryId: "",
    playType: "",
    maxAmount: "",
    blockedNumbers: "",
  });
  const [showForm, setShowForm] = useState(false);
  const [tab, setTab] = useState<"limits" | "blocked">("limits");

  const addLimit = () => {
    const newLimit: LimitEntry = {
      id: Date.now(),
      type: form.type,
      userId: form.type === "user" && form.userId ? Number(form.userId) : null,
      lotteryId: form.lotteryId ? Number(form.lotteryId) : null,
      playType: form.playType || null,
      maxAmount: Number(form.maxAmount) || 0,
      blockedNumbers: form.blockedNumbers.split(",").map((s) => s.trim()).filter(Boolean),
      active: true,
    };
    saveLimits([...limits, newLimit]);
    setForm({ type: "global", userId: "", lotteryId: "", playType: "", maxAmount: "", blockedNumbers: "" });
    setShowForm(false);
    showMsg("Limite creado!");
  };

  const toggleActive = (id: number) => {
    saveLimits(limits.map((l) => l.id === id ? { ...l, active: !l.active } : l));
  };

  const removeLimit = (id: number) => {
    if (confirm("Eliminar este limite?")) saveLimits(limits.filter((l) => l.id !== id));
  };

  const getLotteryName = (id: number | null) => {
    if (!id) return "Todas las loterias";
    const l = allLotteries.find((x: any) => x.id === id);
    return l ? l.name : `ID: ${id}`;
  };

  const getUserName = (id: number | null) => {
    if (!id) return "Todos los usuarios";
    const u = allUsers.find((x: any) => x.id === id);
    return u ? `${u.name} (${u.bankNumber})` : `ID: ${id}`;
  };

  const getPlayTypeLabel = (pt: string | null) => {
    if (!pt) return "Todos los tipos";
    return PLAY_TYPES.find((t) => t.value === pt)?.label || pt;
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {msg && <div className="bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{msg}</div>}

      {/* Tabs */}
      <div className="flex gap-2">
        <button onClick={() => setTab("limits")} className={`flex-1 py-2 rounded-lg text-sm font-bold ${tab === "limits" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-600"}`}>Limites</button>
        <button onClick={() => setTab("blocked")} className={`flex-1 py-2 rounded-lg text-sm font-bold ${tab === "blocked" ? "bg-red-600 text-white" : "bg-gray-100 text-gray-600"}`}>Bloqueos</button>
      </div>

      {/* Create button */}
      {!showForm && (
        <button onClick={() => setShowForm(true)} className="w-full py-2.5 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-700 flex items-center justify-center gap-2">
          <Plus size={16} /> Nuevo {tab === "limits" ? "Limite" : "Bloqueo"}
        </button>
      )}

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-xl border border-green-100 p-4 shadow-sm space-y-3">
          <h3 className="text-sm font-bold text-green-700">{tab === "limits" ? "Nuevo Limite" : "Nuevo Bloqueo"}</h3>

          {/* Scope: global or user */}
          <div>
            <label className="text-[10px] font-medium text-gray-600 mb-1 block">Aplicar a</label>
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as "global" | "user", userId: "" })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm">
              <option value="global">Todos los usuarios (Global)</option>
              <option value="user">Usuario especifico</option>
            </select>
          </div>

          {form.type === "user" && (
            <div>
              <label className="text-[10px] font-medium text-gray-600 mb-1 block">Seleccionar usuario</label>
              <select value={form.userId} onChange={(e) => setForm({ ...form, userId: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm">
                <option value="">-- Seleccionar --</option>
                {allUsers.filter((u: any) => u.role !== "admin").map((u: any) => (
                  <option key={u.id} value={u.id}>{u.name} ({u.bankNumber})</option>
                ))}
              </select>
            </div>
          )}

          {/* Lottery */}
          <div>
            <label className="text-[10px] font-medium text-gray-600 mb-1 block">Loteria</label>
            <select value={form.lotteryId} onChange={(e) => setForm({ ...form, lotteryId: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm">
              <option value="">Todas las loterias</option>
              {allLotteries.map((l: any) => <option key={l.id} value={l.id}>{l.name}</option>)}
            </select>
          </div>

          {/* Play type */}
          <div>
            <label className="text-[10px] font-medium text-gray-600 mb-1 block">Tipo de jugada</label>
            <select value={form.playType} onChange={(e) => setForm({ ...form, playType: e.target.value })} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm">
              <option value="">Todos los tipos</option>
              {PLAY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>

          {tab === "limits" && (
            <div>
              <label className="text-[10px] font-medium text-gray-600 mb-1 block">Monto maximo ($)</label>
              <input type="number" value={form.maxAmount} onChange={(e) => setForm({ ...form, maxAmount: e.target.value })} placeholder="Ej: 500" className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
            </div>
          )}

          <div>
            <label className="text-[10px] font-medium text-gray-600 mb-1 block">Numeros bloqueados (separados por coma)</label>
            <input value={form.blockedNumbers} onChange={(e) => setForm({ ...form, blockedNumbers: e.target.value })} placeholder={tab === "blocked" ? "Ej: 03, 13+23, 04+10+20" : "Ej: 03, 15 (opcional)"} className="w-full px-3 py-2 border border-green-200 rounded-lg text-sm" />
            <p className="text-[10px] text-gray-400 mt-1">Para pale use formato: 13+23. Para tripleta: 04+10+20</p>
          </div>

          <div className="flex gap-2">
            <button onClick={() => setShowForm(false)} className="flex-1 py-2 bg-gray-100 text-gray-600 rounded-lg text-sm font-bold">Cancelar</button>
            <button onClick={addLimit} className="flex-1 py-2 bg-green-600 text-white rounded-lg text-sm font-bold hover:bg-green-700">Guardar</button>
          </div>
        </div>
      )}

      {/* List */}
      <div className="space-y-2">
        {limits.filter((l) => tab === "blocked" ? l.blockedNumbers.length > 0 : true).length === 0 && (
          <div className="text-center py-8 text-gray-400">
            {tab === "limits" ? <Shield size={32} className="mx-auto mb-2 text-green-200" /> : <Lock size={32} className="mx-auto mb-2 text-red-200" />}
            <p className="text-sm">No hay {tab === "limits" ? "limites" : "bloqueos"} configurados</p>
          </div>
        )}

        {limits.filter((l) => tab === "blocked" ? l.blockedNumbers.length > 0 : true).map((limit) => (
          <div key={limit.id} className={`rounded-xl border shadow-sm p-3 ${limit.active ? "bg-white border-gray-100" : "bg-gray-50 border-gray-200 opacity-60"}`}>
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${limit.type === "global" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"}`}>{limit.type === "global" ? "GLOBAL" : "USUARIO"}</span>
                  <span className="text-[10px] px-1.5 py-0.5 bg-green-100 text-green-700 rounded font-bold">{getPlayTypeLabel(limit.playType)}</span>
                  {limit.blockedNumbers.length > 0 && <span className="text-[10px] px-1.5 py-0.5 bg-red-100 text-red-700 rounded font-bold flex items-center gap-0.5"><Lock size={8} /> {limit.blockedNumbers.length} bloqueado(s)</span>}
                </div>
                <p className="text-xs text-gray-600 mt-1">{getLotteryName(limit.lotteryId)}</p>
                {limit.type === "user" && <p className="text-[10px] text-gray-500">{getUserName(limit.userId)}</p>}
                {limit.maxAmount > 0 && <p className="text-xs font-bold text-green-700">Max: ${formatMoney(limit.maxAmount)}</p>}
                {limit.blockedNumbers.length > 0 && (
                  <p className="text-[10px] text-red-500 font-medium">Bloqueados: {limit.blockedNumbers.join(", ")}</p>
                )}
              </div>
              <div className="flex items-center gap-1 ml-2">
                <button onClick={() => toggleActive(limit.id)} className={`px-2 py-1 rounded text-[10px] font-bold ${limit.active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{limit.active ? "ON" : "OFF"}</button>
                <button onClick={() => removeLimit(limit.id)} className="p-1 hover:bg-red-50 rounded"><Trash2 size={14} className="text-red-500" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
