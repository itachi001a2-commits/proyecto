import { useState, useEffect, useCallback, useRef } from "react";
import { jsPDF } from "jspdf";
import QRCode from "qrcode";
import { quickSync } from "@/lib/sync";
import {
  saveDraft, loadDraft, clearDraft, detectPlayType,
  generatePaleCombos, generateDirectoCombos, parseChainInput,
  generateTicketCode, calculateNetDeduction, checkWinningPlays,
  formatMoney, logAudit,
} from "@/store";
import { trpc } from "@/providers/trpc";
import type { Play, PlayType, SessionUser } from "@/store";
import {
  Trash2, Edit2, Check, X, Share2, Ticket,
  ChevronDown, ChevronUp, Plus, Save, FileText,
  Keyboard, Lock, Wallet, Percent, Trophy
} from "lucide-react";

interface VenderScreenProps {
  user: SessionUser;
}

interface DaySchedule {
  open: string;
  close: string;
}

interface Lottery {
  id: number;
  name: string;
  drawTime: string;
  closeTime: string;
  active: boolean;
  schedule: {
    mon: DaySchedule;
    tue: DaySchedule;
    wed: DaySchedule;
    thu: DaySchedule;
    fri: DaySchedule;
    sat: DaySchedule;
    sun: DaySchedule;
  };
}

const DAY_KEYS = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"] as const;
type DayKey = typeof DAY_KEYS[number];

function isLotteryOpenNow(lottery: Lottery): boolean {
  const now = new Date();
  const dayIndex = now.getDay();
  const dayKey = DAY_KEYS[dayIndex];
  const daySched = lottery.schedule[dayKey];
  if (!daySched) return false;
  const currentMins = now.getHours() * 60 + now.getMinutes();
  const [openH, openM] = daySched.open.split(":").map(Number);
  const [closeH, closeM] = daySched.close.split(":").map(Number);
  const openMins = openH * 60 + openM;
  const closeMins = closeH * 60 + closeM;
  return currentMins >= openMins && currentMins < closeMins;
}

function getLotteryStatus(lottery: Lottery): { isOpen: boolean; countdown: string } {
  const now = new Date();
  const dayIndex = now.getDay();
  const dayKey = DAY_KEYS[dayIndex];
  const daySched = lottery.schedule[dayKey];
  if (!daySched) return { isOpen: false, countdown: "Cerrada" };
  const currentMins = now.getHours() * 60 + now.getMinutes();
  const [openH, openM] = daySched.open.split(":").map(Number);
  const [closeH, closeM] = daySched.close.split(":").map(Number);
  const openMins = openH * 60 + openM;
  const closeMins = closeH * 60 + closeM;
  const isOpen = currentMins >= openMins && currentMins < closeMins;
  if (isOpen) {
    const diffMins = closeMins - currentMins;
    const h = Math.floor(diffMins / 60);
    const m = diffMins % 60;
    return { isOpen: true, countdown: h > 0 ? `${h}h ${m}m` : `${m}m` };
  } else if (currentMins < openMins) {
    const diffMins = openMins - currentMins;
    const h = Math.floor(diffMins / 60);
    const m = diffMins % 60;
    return { isOpen: false, countdown: `Abre en ${h}h ${m}m` };
  } else {
    const tomorrowIndex = (dayIndex + 1) % 7;
    const tomorrowKey = DAY_KEYS[tomorrowIndex];
    const tomorrowSched = lottery.schedule[tomorrowKey];
    if (tomorrowSched) {
      return { isOpen: false, countdown: `Cerrada - Abre manana ${tomorrowSched.open}` };
    }
    return { isOpen: false, countdown: "Cerrada" };
  }
}

function migrateLottery(lottery: any): Lottery {
  if (lottery.schedule) return lottery as Lottery;
  const closeTime = lottery.closeTime || lottery.drawTime || "20:00";
  const defaultSched = { open: "07:00", close: closeTime };
  return {
    ...lottery,
    schedule: {
      mon: { ...defaultSched },
      tue: { ...defaultSched },
      wed: { ...defaultSched },
      thu: { ...defaultSched },
      fri: { ...defaultSched },
      sat: { ...defaultSched },
      sun: { ...defaultSched },
    },
  };
}

const mkSched = (close: string): Lottery["schedule"] => {
  const wk = { open: "07:00", close };
  return { mon: wk, tue: wk, wed: wk, thu: wk, fri: wk, sat: wk, sun: wk };
};

export default function VenderScreen({ user }: VenderScreenProps) {
  const allLotteries: Lottery[] = (() => {
    const saved = localStorage.getItem("loteria_loterias");
    if (saved) {
      return JSON.parse(saved).map(migrateLottery).filter((l: Lottery) => l.active);
    }
    return [
      { id: 1, name: "Nacional Noche", drawTime: "20:55", closeTime: "20:45", active: true, schedule: mkSched("20:45") },
      { id: 2, name: "Nacional Tarde", drawTime: "14:55", closeTime: "14:45", active: true, schedule: mkSched("14:45") },
      { id: 3, name: "Leidsa", drawTime: "20:55", closeTime: "20:45", active: true, schedule: mkSched("20:45") },
      { id: 4, name: "Loteria Real", drawTime: "12:55", closeTime: "12:45", active: true, schedule: mkSched("12:45") },
      { id: 5, name: "Loteka", drawTime: "19:55", closeTime: "19:45", active: true, schedule: mkSched("19:45") },
      { id: 6, name: "La Primera", drawTime: "11:55", closeTime: "11:45", active: true, schedule: mkSched("11:45") },
      { id: 7, name: "La Suerte", drawTime: "12:55", closeTime: "12:45", active: true, schedule: mkSched("12:45") },
      { id: 8, name: "LoteDom", drawTime: "20:00", closeTime: "19:45", active: true, schedule: mkSched("19:45") },
      { id: 9, name: "Anguilla", drawTime: "10:00", closeTime: "09:45", active: true, schedule: mkSched("09:45") },
      { id: 10, name: "NY Tarde", drawTime: "14:30", closeTime: "14:15", active: true, schedule: mkSched("14:15") },
      { id: 11, name: "NY Noche", drawTime: "22:30", closeTime: "22:15", active: true, schedule: mkSched("22:15") },
      { id: 12, name: "FL Tarde", drawTime: "13:30", closeTime: "13:15", active: true, schedule: mkSched("13:15") },
      { id: 13, name: "FL Noche", drawTime: "21:45", closeTime: "21:30", active: true, schedule: mkSched("21:30") },
    ];
  })();

  const openLotteries = allLotteries.filter(isLotteryOpenNow);

  const [plays, setPlays] = useState<Play[]>(() => loadDraft());
  const [input, setInput] = useState("");
  const [amount, setAmount] = useState("");
  const [selectedLotteries, setSelectedLotteries] = useState<Lottery[]>([]);
  const [showLotteryModal, setShowLotteryModal] = useState(false);
  const [countdowns, setCountdowns] = useState<Record<number, string>>({});
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editAmount, setEditAmount] = useState("");
  const [message, setMessage] = useState("");
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [lastTicket, setLastTicket] = useState<any>(null);
  const [showTicketModal, setShowTicketModal] = useState(false);
  const [activeField, setActiveField] = useState<"numero" | "monto">("numero");
  const [showKeypad, setShowKeypad] = useState(true);
  const [userCredit, setUserCredit] = useState<number>(Number(user.credit) || 0);
  const [userCommission] = useState<number>(Number(user.commission) || 0);
  const qrRef = useRef<HTMLCanvasElement>(null);
  const touchStartY = useRef<number>(0);

  // tRPC hooks for credit and tickets
  const utils = trpc.useUtils();
  const updateCreditMut = trpc.lotteryUser.updateCredit.useMutation({
    onSuccess: () => utils.lotteryUser.list.invalidate(),
  });
  const createTicketMut = trpc.ticket.create.useMutation({
    onSuccess: () => utils.ticket.list.invalidate(),
  });
  const userByIdQuery = trpc.lotteryUser.byId.useQuery(
    { id: user.id },
    { enabled: false }
  );

  const refreshCreditFromDB = async () => {
    try {
      const result = await userByIdQuery.refetch();
      if (result.data) {
        const newCredit = Number(result.data.credit) || 0;
        setUserCredit(newCredit);
        return newCredit;
      }
    } catch {
      // fallback
    }
    return userCredit;
  };

  // Refresh credit periodically
  useEffect(() => {
    const interval = setInterval(() => {
      refreshCreditFromDB();
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (openLotteries.length > 0 && selectedLotteries.length === 0) {
      setSelectedLotteries([openLotteries[0]]);
    }
  }, []);

  useEffect(() => {
    const calculateCountdown = () => {
      const newCountdowns: Record<number, string> = {};
      allLotteries.forEach((lottery) => {
        const status = getLotteryStatus(lottery);
        newCountdowns[lottery.id] = status.countdown;
      });
      setCountdowns(newCountdowns);
    };
    calculateCountdown();
    const interval = setInterval(calculateCountdown, 30000);
    return () => clearInterval(interval);
  }, [allLotteries]);

  // Auto-clear selected lotteries that have closed
  useEffect(() => {
    const closedSelected = selectedLotteries.filter((l) => !isLotteryOpenNow(l));
    if (closedSelected.length > 0) {
      setSelectedLotteries((prev) => prev.filter((l) => isLotteryOpenNow(l)));
      showMsg(`${closedSelected.map((l) => l.name).join(", ")} ha cerrado`);
    }
  }, [openLotteries]);

  useEffect(() => { saveDraft(plays); }, [plays]);

  const total = plays.reduce((sum, p) => sum + p.amount, 0);
  const showMsg = useCallback((msg: string) => { setMessage(msg); setTimeout(() => setMessage(""), 3000); }, []);

  const getPotentialPrize = useCallback((play: Play): string => {
    const prize = prizeList.find((p) => p.playType === play.type);
    if (!prize) return "0";
    const amt = play.amount;
    let mult = 0;
    switch (play.type) {
      case "directo": mult = Number(prize.firstPrizeMultiplier || 0); break;
      case "pale": mult = Number(prize.paleFirstSecondMultiplier || 0); break;
      case "terna": mult = Number(prize.fixedMultiplier || 0); break;
      case "cuatrena": mult = Number(prize.fixedMultiplier || 0); break;
      case "tripleta": mult = Number(prize.fixedMultiplier || 0); break;
    }
    return formatMoney(amt * mult);
  }, []);

  // Read max bet limit from config - reads fresh each call
  function getMaxBetLimit(): number {
    const config = localStorage.getItem("loteria_config");
    if (config) { try { return Number(JSON.parse(config).maxBetAmount) || 0; } catch { return 0; } }
    return 0;
  }

  // ─── LIMITS & BLOCKS CHECK ─────────────────────────────────────────
  interface LimitEntry {
    id: number;
    type: "global" | "user";
    userId: number | null;
    lotteryId: number | null;
    playType: string | null;
    maxAmount: number;
    blockedNumbers: string[];
    active: boolean;
  }

  function normalizeBlockedNumber(number: string, type: string): string {
    const digits = number.replace(/[^0-9]/g, "");
    if ((type === "pale" || type === "terna" || type === "cuatrena") && digits.length === 4 && !number.includes("+")) {
      return [digits.slice(0, 2), digits.slice(2, 4)].sort().join("+");
    }
    if ((type === "tripleta") && digits.length === 6 && !number.includes("+")) {
      return [digits.slice(0, 2), digits.slice(2, 4), digits.slice(4, 6)].sort().join("+");
    }
    const parts = number.split("+").map((p) => p.trim()).filter(Boolean);
    if (parts.length >= 2) return parts.sort().join("+");
    return number.trim();
  }

  function checkPlayLimit(lotteryId: number, playType: string, number: string, amount: number, userId: number): { allowed: boolean; reason?: string } {
    const limitsRaw = localStorage.getItem("loteria_limits");
    if (!limitsRaw) return { allowed: true };
    const limits: LimitEntry[] = JSON.parse(limitsRaw);
    const normalizedNum = normalizeBlockedNumber(number, playType);

    // Find applicable limits (active, matching lottery/type/user)
    const applicable = limits.filter((l) => {
      if (!l.active) return false;
      // Check user match (global applies to all, user must match)
      if (l.type === "user" && l.userId !== userId) return false;
      // Check lottery match (null = all)
      if (l.lotteryId !== null && l.lotteryId !== lotteryId) return false;
      // Check play type match (null = all)
      if (l.playType !== null && l.playType !== playType) return false;
      return true;
    });

    // Check blocked numbers first
    for (const limit of applicable) {
      for (const blocked of limit.blockedNumbers) {
        const normalizedBlocked = normalizeBlockedNumber(blocked, playType);
        if (normalizedNum === normalizedBlocked) {
          return { allowed: false, reason: `"${number}" esta BLOQUEADO${limit.lotteryId ? ` en ${(allLotteries.find((lo: Lottery) => lo.id === limit.lotteryId)?.name || "")}` : ""}` };
        }
      }
    }

    // Check max amount
    for (const limit of applicable) {
      if (limit.maxAmount > 0 && amount > limit.maxAmount) {
        return { allowed: false, reason: `Limite de $${formatMoney(limit.maxAmount)} para ${getPlayTypeLabel(playType)}${limit.lotteryId ? ` en ${(allLotteries.find((lo: Lottery) => lo.id === limit.lotteryId)?.name || "")}` : ""}` };
      }
    }

    return { allowed: true };
  }

  function getPlayTypeLabel(pt: string): string {
    const labels: Record<string, string> = { directo: "Directo", pale: "Pale", terna: "3 Cifras", cuatrena: "4 Cifras", tripleta: "Tripleta" };
    return labels[pt] || pt;
  }

  const normalizePlayNumber = useCallback((number: string, type: PlayType): string => {
    const digits = number.replace(/[^0-9]/g, "");
    if (type === "pale") {
      // Handle "1323" (4 digits without +) → split as "13" + "23"
      if (digits.length === 4 && !number.includes("+")) {
        const parts = [digits.slice(0, 2), digits.slice(2, 4)];
        return parts.sort().join("+");
      }
      const parts = number.split("+").map((p) => p.trim()).filter(Boolean);
      if (parts.length === 2) return parts.sort().join("+");
    }
    if (type === "tripleta") {
      // Handle "042010" (6 digits without +) → split as "04" + "20" + "10"
      if (digits.length === 6 && !number.includes("+")) {
        const parts = [digits.slice(0, 2), digits.slice(2, 4), digits.slice(4, 6)];
        return parts.sort().join("+");
      }
      const parts = number.split("+").map((p) => p.trim()).filter(Boolean);
      if (parts.length === 3) return parts.sort().join("+");
    }
    return number;
  }, []);

  const addPlay = useCallback(() => {
    if (selectedLotteries.length === 0) { showMsg("Seleccione al menos una loteria"); return; }
    // Check credit
    const playCost = Number(amount) || 0;
    if (playCost > 0 && playCost > userCredit) { showMsg(`Credito insuficiente. Disponible: $${formatMoney(userCredit)}`); return; }
    const closedSelected = selectedLotteries.filter((l) => !isLotteryOpenNow(l));
    if (closedSelected.length > 0) {
      showMsg(`${closedSelected.map((l) => l.name).join(", ")} ha cerrado. Seleccione otra.`);
      setSelectedLotteries((prev) => prev.filter((l) => isLotteryOpenNow(l)));
      return;
    }
    if (!input.trim()) { showMsg("Ingrese un numero"); return; }
    if (!amount || Number(amount) <= 0) { showMsg("Ingrese monto valido"); return; }

    const trimmed = input.trim();
    const isCombo = trimmed.endsWith("/");
    const baseNumber = isCombo ? trimmed.slice(0, -1) : trimmed;

    // Detect pale/tripleta with "+" before chain parsing
    // "13+23" (2 parts × 2 digits) = pale | "04+10+20" (3 parts × 2 digits) = tripleta
    function detectChainType(inputStr: string): { parts: string[]; isSinglePlay: boolean } {
      const rawParts = inputStr.split("+").map((s) => s.trim()).filter(Boolean);
      if (rawParts.length === 2 && rawParts.every((p) => p.length === 2 && /^\d+$/.test(p))) {
        return { parts: [inputStr], isSinglePlay: true };
      }
      if (rawParts.length === 3 && rawParts.every((p) => p.length === 2 && /^\d+$/.test(p))) {
        return { parts: [inputStr], isSinglePlay: true };
      }
      return { parts: rawParts, isSinglePlay: false };
    }
    const chainResult = detectChainType(baseNumber);
    const chainParts = chainResult.parts;

    setPlays((prevPlays) => {
      const newPlays = [...prevPlays];
      for (const lottery of selectedLotteries) {
        for (const part of chainParts) {
          const cleanDigits = part.replace(/[^0-9]/g, "");
          let combosToAdd: { number: string; type: PlayType }[] = [];

          if (isCombo) {
            if (cleanDigits.length === 4) {
              generatePaleCombos(cleanDigits).forEach((combo) => combosToAdd.push({ number: combo, type: "pale" }));
            } else if (cleanDigits.length >= 2 && cleanDigits.length <= 3) {
              generateDirectoCombos(cleanDigits).forEach((combo) => combosToAdd.push({ number: combo, type: "directo" }));
            } else {
              const detectedType = detectPlayType(part);
              if (detectedType === "invalido" as PlayType) { showMsg(`"${part}" no es una jugada valida. Use 2=directo, 4=pale, 6=tripleta`); continue; }
              combosToAdd.push({ number: part, type: detectedType });
            }
          } else {
            const detectedType = detectPlayType(part);
            if (detectedType === "invalido" as PlayType) { showMsg(`"${part}" no es una jugada valida. Use 2=directo, 4=pale, 6=tripleta`); continue; }
            combosToAdd.push({ number: part, type: detectedType });
          }

          // Check limits before adding
          for (const combo of combosToAdd) {
            const limitCheck = checkPlayLimit(lottery.id, combo.type, combo.number, Number(amount), user.id);
            if (!limitCheck.allowed) { showMsg(limitCheck.reason || "Jugada no permitida"); continue; }

            const existingIndex = newPlays.findIndex(
              (p) => p.type === combo.type && p.lotteryId === lottery.id && normalizePlayNumber(p.number, p.type) === normalizePlayNumber(combo.number, combo.type)
            );
            const limit = getMaxBetLimit();
            if (existingIndex >= 0) {
              // Same play exists - merge amounts, respecting max limit
              const currentAmt = newPlays[existingIndex].amount;
              const newAmt = currentAmt + Number(amount);
              if (limit > 0 && newAmt > limit) {
                newPlays[existingIndex] = { ...newPlays[existingIndex], amount: limit };
                showMsg(`Limite de $${limit} alcanzado para ${combo.number}`);
              } else {
                newPlays[existingIndex] = { ...newPlays[existingIndex], amount: newAmt };
              }
            } else if (limit > 0 && Number(amount) > limit) {
              // New play but amount exceeds limit
              newPlays.push({
                id: Math.random().toString(36).substr(2, 9),
                number: combo.number,
                amount: limit,
                type: combo.type,
                lotteryId: lottery.id,
                lotteryName: lottery.name,
              });
              showMsg(`Monto limitado a $${limit} para ${combo.number}`);
            } else {
              newPlays.push({
                id: Math.random().toString(36).substr(2, 9),
                number: combo.number,
                amount: Number(amount),
                type: combo.type,
                lotteryId: lottery.id,
                lotteryName: lottery.name,
              });
            }
          }
        }
      }
      return newPlays;
    });
    setInput("");
  }, [input, amount, selectedLotteries, showMsg, normalizePlayNumber, userCredit]);

  const handleKeypad = useCallback((key: string) => {
    if (key === "+" && input.trim() && amount && Number(amount) > 0) {
      addPlay();
      return;
    }
    if (activeField === "monto") {
      if (key === "C") setAmount("");
      else if (key === "DEL") setAmount((prev) => prev.slice(0, -1));
      else if (key === ".") setAmount((prev) => prev.includes(".") ? prev : prev + ".");
      else if (key !== "+" && key !== "/") setAmount((prev) => prev + key);
    } else {
      if (key === "C") setInput("");
      else if (key === "DEL") setInput((prev) => prev.slice(0, -1));
      else if (key === "+") setInput((prev) => prev + "+");
      else if (key === ".") setInput((prev) => prev + ".");
      else if (key === "/") setInput((prev) => prev + "/");
      else setInput((prev) => prev + key);
    }
  }, [activeField, input, amount, addPlay]);

  const deletePlay = useCallback((id: string) => { setPlays((prev) => prev.filter((p) => p.id !== id)); }, []);
  const startEdit = useCallback((play: Play) => { setEditingId(play.id); setEditAmount(play.amount.toString()); }, []);
  const saveEdit = useCallback((id: string) => {
    const newAmount = Number(editAmount) || 0;
    const limit = getMaxBetLimit();
    if (limit > 0 && newAmount > limit) {
      setPlays((prev) => prev.map((p) => p.id === id ? { ...p, amount: limit } : p));
      showMsg(`Monto limitado a $${limit}`);
    } else {
      setPlays((prev) => prev.map((p) => p.id === id ? { ...p, amount: newAmount } : p));
    }
    setEditingId(null);
  }, [editAmount]);
  const clearAll = useCallback(() => { setPlays([]); setInput(""); clearDraft(); }, []);

  const handleTouchStart = useCallback((e: React.TouchEvent) => { touchStartY.current = e.touches[0].clientY; }, []);
  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    const diff = e.changedTouches[0].clientY - touchStartY.current;
    if (diff > 50) setShowKeypad(false);
    else if (diff < -50) setShowKeypad(true);
  }, []);

  const handleSaveTicket = useCallback(() => {
    if (plays.length === 0) { showMsg("Agregue jugadas primero"); return; }
    setShowConfirmModal(true);
  }, [plays.length, showMsg]);

  const generateQR = async (data: string): Promise<string> => {
    try { return await QRCode.toDataURL(data, { width: 200, margin: 2 }); } catch { return ""; }
  };

  const buildPDF = async (ticketData: any): Promise<jsPDF> => {
    const doc = new jsPDF({ unit: "mm", format: [80, 150 + ticketData.plays.length * 8] });
    const pageWidth = 80;
    let y = 8;
    doc.setFillColor(76, 175, 80);
    doc.rect(0, 0, pageWidth, 22, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14); doc.setFont("helvetica", "bold");
    doc.text(ticketData.groupName || "BANCA VICTORIA", pageWidth / 2, y + 5, { align: "center" });
    doc.setFontSize(9); doc.setFont("helvetica", "normal");
    doc.text("Sistema de Loteria", pageWidth / 2, y + 10, { align: "center" });
    y = 28;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(8);
    doc.text(`Ticket No: ${ticketData.code}`, 5, y); y += 5;
    doc.text(`Fecha: ${ticketData.date}`, 5, y); y += 5;
    doc.text(`Hora: ${ticketData.time}`, 5, y); y += 5;
    doc.text(`Terminal: ${ticketData.terminal}`, 5, y); y += 5;
    doc.text(`Vendedor: ${ticketData.seller}`, 5, y); y += 5;
    if (ticketData.groupName) { doc.text(`Grupo: ${ticketData.groupName}`, 5, y); y += 5; }
    doc.text(`Loteria: ${ticketData.lottery}`, 5, y); y += 8;
    doc.setDrawColor(200, 200, 200);
    doc.line(5, y - 3, pageWidth - 5, y - 3);
    doc.setFontSize(9); doc.setFont("helvetica", "bold");
    doc.text("JUGADAS", 5, y); y += 6;
    doc.setFont("helvetica", "normal"); doc.setFontSize(8);
    ticketData.plays.forEach((play: any) => {
      doc.text(`${play.number}`, 5, y);
      doc.text(`${play.type.toUpperCase()}`, 35, y);
      doc.text(`$${formatMoney(play.amount)}`, pageWidth - 5, y, { align: "right" });
      y += 6;
    });
    y += 2;
    doc.line(5, y - 3, pageWidth - 5, y - 3);
    doc.setFontSize(11); doc.setFont("helvetica", "bold");
    doc.text("TOTAL:", 5, y + 4);
    doc.text(`$${formatMoney(Number(ticketData.total))}`, pageWidth - 5, y + 4, { align: "right" });
    y += 12;
    const qrData = `TICKET:${ticketData.code}|DATE:${ticketData.date}|TIME:${ticketData.time}|TERMINAL:${ticketData.terminal}|TOTAL:${ticketData.total}`;
    const qrDataUrl = await generateQR(qrData);
    if (qrDataUrl) { doc.addImage(qrDataUrl, "PNG", (pageWidth - 30) / 2, y, 30, 30); y += 35; }
    doc.setFontSize(7); doc.setFont("helvetica", "normal");
    doc.setTextColor(128, 128, 128);
    doc.text("Gracias por jugar con nosotros!", pageWidth / 2, y, { align: "center" });
    return doc;
  };

  const downloadPDF = async (ticketData: any) => {
    const doc = await buildPDF(ticketData);
    doc.save(`${ticketData.code}.pdf`);
  };

  const generatePDFDataUrl = async (ticketData: any): Promise<string> => {
    const doc = await buildPDF(ticketData);
    return doc.output("datauristring");
  };

  const confirmSave = useCallback(async () => {
    if (selectedLotteries.length === 0) return;
    // Check credit
    const netDeduction = calculateNetDeduction(total, userCommission);
    if (netDeduction > userCredit) { showMsg(`Credito insuficiente. Necesita: $${formatMoney(netDeduction)}, Disponible: $${formatMoney(userCredit)}`); setShowConfirmModal(false); return; }
    
    // Deduct credit via API
    const newCredit = userCredit - netDeduction;
    try {
      await updateCreditMut.mutateAsync({ id: user.id, credit: String(newCredit) });
      setUserCredit(newCredit);
    } catch (err: any) {
      showMsg("Error al descontar credito: " + (err.message || "Intente de nuevo"));
      setShowConfirmModal(false);
      return;
    }
    
    // Check for winners
    const { prize: totalPrize, details: prizeDetails } = checkWinningPlays(plays);
    let prizeMsg = "";
    if (totalPrize > 0) {
      const creditWithPrize = newCredit + totalPrize;
      try {
        await updateCreditMut.mutateAsync({ id: user.id, credit: String(creditWithPrize) });
        setUserCredit(creditWithPrize);
        prizeMsg = ` | Premio ganado: $${formatMoney(totalPrize)}!`;
      } catch {
        // prize failed but ticket still saved
      }
    }
    
    // Generate ticket
    const code = generateTicketCode();
    const now = new Date();
    const date = now.toLocaleDateString();
    const time = now.toLocaleTimeString();
    const lotteryNames = selectedLotteries.map((l) => l.name).join(", ");
    const gs = JSON.parse(localStorage.getItem("loteria_groups") || "[]");
    const groupName = user.groupId ? (gs.find((g: any) => g.id === user.groupId)?.name || "") : "";
    
    // Build ticket data
    const ticketData: any = {
      id: Date.now(), code, userId: user.id,
      lotteryId: selectedLotteries[0].id,
      total: formatMoney(total), status: "active", date, time,
      createdAt: now.toISOString(),
      netDeduction: netDeduction.toFixed(2),
      commission: String(userCommission),
      plays: plays.map((p) => ({ ...p, id: Math.random().toString(36).substr(2, 9) })),
      terminal: user.bankNumber, seller: user.name, lottery: lotteryNames, groupName,
    };
    
    // Generate PDF
    try {
      const pdfDataUrl = await generatePDFDataUrl(ticketData);
      ticketData.pdfDataUrl = pdfDataUrl;
    } catch {
      // PDF failed, continue
    }
    
    // Save ticket to database via tRPC - MUST succeed
    let ticketId: number;
    try {
      const playList = ticketData.plays.map((p: any) => ({
        number: p.number,
        amount: String(p.amount),
        type: p.type,
        lotteryId: p.lotteryId,
      }));
      const result = await createTicketMut.mutateAsync({
        code,
        userId: user.id,
        lotteryId: selectedLotteries[0].id,
        total: formatMoney(total),
        playList,
      });
      ticketId = result.ticketId;
      ticketData.id = ticketId;
    } catch (err: any) {
      showMsg("Error al guardar ticket: " + (err.message || "Verifique su conexion"));
      setShowConfirmModal(false);
      return;
    }
    
    // Log
    logAudit({
      type: "ticket_sale",
      userId: user.id,
      userName: user.name,
      groupId: user.groupId,
      amount: total,
      description: `Venta: ${ticketData.plays.length} jugada(s) por $${formatMoney(total)} | Comision: $${formatMoney(total * (userCommission / 100))}`,
      ticketCode: code,
      balanceAfter: newCredit,
    });
    if (totalPrize > 0) {
      logAudit({
        type: "prize_win",
        userId: user.id,
        userName: user.name,
        groupId: user.groupId,
        amount: totalPrize,
        description: `Premio ganado: $${formatMoney(totalPrize)} | ${prizeDetails.join(", ")}`,
        ticketCode: code,
        balanceAfter: newCredit + totalPrize,
      });
    }
    
    clearDraft();
    setPlays([]);
    setLastTicket(ticketData);
    setShowConfirmModal(false);
    setShowTicketModal(true);
    setMessage(`Ticket ${code} guardado! -$${formatMoney(netDeduction)}${prizeMsg}`);
    setTimeout(() => setMessage(""), 5000);
    quickSync();
  }, [plays, selectedLotteries, total, user, userCredit, userCommission]);

  const shareWhatsApp = useCallback(() => {
    const ticket = lastTicket;
    if (!ticket) { showMsg("Guarde un ticket primero"); return; }
    const lines = ticket.plays.map((p: any) => `${p.number} - ${p.type.toUpperCase()} - $${formatMoney(p.amount)}`).join("\n");
    const gs = JSON.parse(localStorage.getItem("loteria_groups") || "[]");
    const groupName = user.groupId ? (gs.find((g: any) => g.id === user.groupId)?.name || "") : "";
    const appName = groupName || "BANCA VICTORIA";
    const subLine = groupName ? "\n_Banca Victoria_" : "";
    const text = `*${appName}*${subLine}\nTicket: *${ticket.code}*\nFecha: ${ticket.date}\nHora: ${ticket.time}\nTerminal: ${ticket.terminal}\nVendedor: ${ticket.seller}\nLoteria: ${ticket.lottery}\n\n*JUGADAS:*\n${lines}\n\n*Total: $${ticket.total}*\n\nCodigo QR: ${ticket.code}`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  }, [lastTicket, showMsg, user]);

  const prizeList = (() => {
    const saved = localStorage.getItem("loteria_prizes");
    if (saved) return JSON.parse(saved);
    return [
      { id: 1, playType: "directo", firstPrizeMultiplier: "50", secondPrizeMultiplier: "15", thirdPrizeMultiplier: "10", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "0" },
      { id: 2, playType: "pale", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "25", paleFirstThirdMultiplier: "20", paleSecondThirdMultiplier: "15", fixedMultiplier: "0" },
      { id: 3, playType: "terna", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "500" },
      { id: 4, playType: "cuatrena", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "4000" },
      { id: 5, playType: "tripleta", firstPrizeMultiplier: "0", secondPrizeMultiplier: "0", thirdPrizeMultiplier: "0", paleFirstSecondMultiplier: "0", paleFirstThirdMultiplier: "0", paleSecondThirdMultiplier: "0", fixedMultiplier: "10000" },
    ];
  })();

  // ─── RENDER ─────────────────────────────────────────────────────────
  return (
    <div className="h-full flex flex-col">
      {/* Header: Lottery Selector */}
      <div className="px-3 py-1.5 bg-gradient-to-r from-green-600 to-green-700 shrink-0">
        <button onClick={() => setShowLotteryModal(true)} className="w-full flex items-center justify-between px-3 py-1.5 bg-white/15 backdrop-blur rounded-lg hover:bg-white/25 transition-all border border-white/20">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <Ticket size={16} className="text-white shrink-0" />
            <div className="text-left min-w-0 flex-1">
              <p className="text-sm font-bold text-white truncate">
                {selectedLotteries.length === 0 ? "Seleccionar Loterias" :
                 selectedLotteries.length === 1 ? selectedLotteries[0].name :
                 `${selectedLotteries.length} loterias`}
              </p>
              <p className="text-[10px] text-green-200">
                {selectedLotteries.length > 0
                  ? selectedLotteries.map((l) => `${l.name} (${countdowns[l.id] || "..."})`).join(", ")
                  : "Toca para seleccionar"}
              </p>
            </div>
          </div>
          <ChevronDown size={16} className="text-white/80 shrink-0 ml-2" />
        </button>
      </div>

      {/* Credit bar */}
      <div className="px-3 py-1 bg-green-800/50 shrink-0 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Wallet size={12} className="text-green-200" />
          <span className="text-[10px] text-green-200">Credito: <span className="font-bold text-white">${formatMoney(userCredit)}</span></span>
        </div>
        <div className="flex items-center gap-1.5">
          <Percent size={12} className="text-green-200" />
          <span className="text-[10px] text-green-200">Comision: <span className="font-bold text-white">{userCommission}%</span></span>
        </div>
      </div>

      {/* Warning when no lotteries are open */}
      {openLotteries.length === 0 && (
        <div className="mx-3 mt-2 bg-red-600 text-white px-3 py-2 rounded-lg text-sm text-center flex items-center justify-center gap-2">
          <Lock size={14} /> No hay loterias abiertas en este momento
        </div>
      )}

      {message && <div className="mx-3 mt-2 bg-green-600 text-white px-3 py-2 rounded-lg text-sm text-center">{message}</div>}

      {/* Plays Table */}
      <div className="flex-1 overflow-y-auto custom-scrollbar px-3 py-2">
        {plays.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400 py-8">
            <Ticket size={48} className="mb-3 text-green-200" />
            <p className="text-sm">Sin jugadas. Ingrese numeros y monto.</p>
            <p className="text-xs mt-1 text-gray-300">Use + para cadenas, / para combos</p>
          </div>
        ) : (
          <div className="space-y-2">
            {plays.map((play) => (
              <div key={play.id} className="play-row bg-white rounded-xl border border-green-200 p-3 shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div>
                      <p className="text-lg font-bold text-gray-900">{play.number}</p>
                      <p className="text-xs text-green-600 font-semibold uppercase tracking-wide">{play.type} - {play.lotteryName}</p>
                    </div>
                  </div>
                  {editingId === play.id ? (
                    <div className="flex items-center gap-1.5">
                      <input type="number" value={editAmount} onChange={(e) => setEditAmount(e.target.value)} className="w-20 px-2 py-1.5 text-base border border-green-300 rounded-lg text-right font-bold" autoFocus />
                      <button onClick={() => saveEdit(play.id)} className="p-2 bg-green-100 rounded-lg"><Check size={16} className="text-green-700" /></button>
                      <button onClick={() => setEditingId(null)} className="p-2 bg-gray-100 rounded-lg"><X size={16} className="text-gray-600" /></button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <div className="text-right mr-2">
                        <span className="text-lg font-bold text-green-700">${formatMoney(play.amount)}</span>
                        <span className="text-[10px] block text-yellow-600 font-medium">Paga: ${getPotentialPrize(play)}</span>
                      </div>
                      <div className="flex flex-col gap-1">
                        <button onClick={() => startEdit(play)} className="p-1.5 bg-blue-50 rounded-md hover:bg-blue-100"><Edit2 size={14} className="text-blue-600" /></button>
                        <button onClick={() => deletePlay(play.id)} className="p-1.5 bg-red-50 rounded-md hover:bg-red-100"><Trash2 size={14} className="text-red-500" /></button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Total Bar */}
      {plays.length > 0 && (
        <div className="px-3 py-2 bg-gradient-to-r from-green-600 to-green-700 text-white shrink-0">
          <div className="flex items-center justify-between">
            <button onClick={clearAll} className="flex items-center gap-1.5 text-xs text-red-200"><Trash2 size={14} /> Limpiar</button>
            <p className="text-[10px] text-green-200">{plays.length} jugada(s)</p>
            <p className="text-xl font-extrabold">${formatMoney(total)}</p>
          </div>
          {userCommission > 0 && (
            <div className="flex items-center justify-between mt-1 pt-1 border-t border-white/20">
              <p className="text-[10px] text-green-200">Desc. comision ({userCommission}%):</p>
              <p className="text-[10px] font-bold text-yellow-200">-${formatMoney(total * (userCommission / 100))}</p>
            </div>
          )}
        </div>
      )}

      {/* Input Area */}
      <div className="px-3 pt-2 pb-1 bg-white border-t border-green-100 shrink-0 space-y-1.5">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <input type="text" value={input} readOnly inputMode="none" className={`w-full px-3 py-2 text-base font-bold border-2 rounded-xl outline-none bg-green-50/50 text-gray-900 placeholder-green-300 cursor-pointer transition-all ${activeField === "numero" ? "border-green-500 ring-2 ring-green-200" : "border-green-200"}`} placeholder="Numero" onClick={() => { setActiveField("numero"); setShowKeypad(true); }} />
            {input && (
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-green-600 font-medium bg-green-100 px-2 py-0.5 rounded-full">
                {input.endsWith("/") ? (input.replace(/[^0-9]/g, "").length === 4 ? "COMBO PALE" : "COMBO DIRECTO") : detectPlayType(input).toUpperCase()}
              </span>
            )}
          </div>
          <div className="w-28">
            <input type="text" value={amount} readOnly inputMode="none" className={`w-full px-3 py-2 text-base font-bold border-2 rounded-xl outline-none bg-green-50/50 text-green-700 placeholder-green-300 text-right cursor-pointer transition-all ${activeField === "monto" ? "border-green-500 ring-2 ring-green-200" : "border-green-200"}`} placeholder="Monto" onClick={() => { setActiveField("monto"); setShowKeypad(true); }} />
          </div>
        </div>
      </div>

      {/* Swipe handle bar */}
      {showKeypad && (
        <div className="shrink-0 bg-white px-3 pb-1 pt-0 cursor-grab active:cursor-grabbing select-none" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd} onClick={() => setShowKeypad(false)}>
          <div className="flex flex-col items-center gap-0.5">
            <div className="w-10 h-1 bg-gray-300 rounded-full" />
            <span className="text-[9px] text-gray-400">Desliza o toca para ocultar</span>
          </div>
        </div>
      )}

      {/* Floating button to show keypad when hidden */}
      {!showKeypad && (
        <div className="shrink-0 bg-white px-3 py-1 border-t border-green-100">
          <button onClick={() => setShowKeypad(true)} className="w-full flex items-center justify-center gap-2 py-2 bg-green-50 rounded-xl border border-green-200 hover:bg-green-100 transition-all">
            <Keyboard size={16} className="text-green-600" />
            <ChevronUp size={14} className="text-green-600" />
            <span className="text-xs font-semibold text-green-700">Mostrar Teclado</span>
          </button>
        </div>
      )}

      {/* Keypad - collapsible */}
      {showKeypad && (
        <div className="px-3 pb-1.5 pt-1 bg-white shrink-0 transition-all" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
          <div className="grid grid-cols-4 gap-1">
            <button onClick={() => handleKeypad("1")} className="keypad-btn">1</button>
            <button onClick={() => handleKeypad("2")} className="keypad-btn">2</button>
            <button onClick={() => handleKeypad("3")} className="keypad-btn">3</button>
            <button onClick={() => handleKeypad("+")} className="keypad-btn-green" title="Agregar jugada"><Plus size={18} /></button>
            <button onClick={() => handleKeypad("4")} className="keypad-btn">4</button>
            <button onClick={() => handleKeypad("5")} className="keypad-btn">5</button>
            <button onClick={() => handleKeypad("6")} className="keypad-btn">6</button>
            <button onClick={() => handleKeypad("/")} className="keypad-btn-green text-sm">/</button>
            <button onClick={() => handleKeypad("7")} className="keypad-btn">7</button>
            <button onClick={() => handleKeypad("8")} className="keypad-btn">8</button>
            <button onClick={() => handleKeypad("9")} className="keypad-btn">9</button>
            <button onClick={() => handleKeypad(".")} className="keypad-btn-green">.</button>
            <button onClick={() => handleKeypad("C")} className="keypad-btn-red">C</button>
            <button onClick={() => handleKeypad("0")} className="keypad-btn">0</button>
            <button onClick={() => handleKeypad("DEL")} className="keypad-btn-red text-xs">DEL</button>
            <button onClick={() => addPlay()} className="keypad-btn-green" title="Agregar"><Plus size={18} /></button>
            <button onClick={handleSaveTicket} className="col-span-2 keypad-btn-green flex items-center justify-center gap-1 text-sm"><Save size={16} /> Guardar</button>
            <button onClick={() => { if (lastTicket) downloadPDF(lastTicket); else showMsg("Guarde un ticket primero"); }} className="keypad-btn flex items-center justify-center text-red-600"><FileText size={16} /></button>
            <button onClick={shareWhatsApp} className="keypad-btn flex items-center justify-center text-green-600"><Share2 size={16} /></button>
          </div>
        </div>
      )}

      {/* Lottery Modal */}
      {showLotteryModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm max-h-[80%] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <h3 className="font-bold text-lg text-gray-900">Seleccionar Loterias</h3>
              <button onClick={() => setShowLotteryModal(false)} className="p-1.5 hover:bg-gray-100 rounded-lg"><X size={20} className="text-gray-500" /></button>
            </div>
            <div className="px-4 py-2 bg-green-50 border-b border-green-100">
              <p className="text-xs text-green-700">Toca para seleccionar multiples loterias. La jugada se creara en TODAS las seleccionadas.</p>
            </div>
            <div className="overflow-y-auto custom-scrollbar p-3 space-y-2 flex-1">
              {/* Open lotteries */}
              {openLotteries.length > 0 && <div className="text-[10px] font-bold text-green-700 mb-1">ABIERTAS AHORA</div>}
              {openLotteries.map((lottery) => {
                const isSelected = selectedLotteries.some((l) => l.id === lottery.id);
                const status = getLotteryStatus(lottery);
                return (
                  <button key={lottery.id} onClick={() => { setSelectedLotteries((prev) => isSelected ? prev.filter((l) => l.id !== lottery.id) : [...prev, lottery]); }} className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left ${isSelected ? "bg-green-50 border-green-400" : "bg-white border-gray-200 hover:border-green-300"}`}>
                    <div className={`w-6 h-6 rounded-md border-2 flex items-center justify-center shrink-0 ${isSelected ? "bg-green-500 border-green-500" : "border-gray-300"}`}>{isSelected && <Check size={14} className="text-white" />}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900">{lottery.name}</p>
                      <p className="text-[10px] text-gray-500">Cierra en: <span className="font-bold text-green-600">{status.countdown}</span></p>
                    </div>
                  </button>
                );
              })}
              {/* Closed lotteries */}
              {allLotteries.filter((l) => !isLotteryOpenNow(l)).length > 0 && (
                <div className="mt-3">
                  <div className="text-[10px] font-bold text-red-500 mb-1">CERRADAS</div>
                  {allLotteries.filter((l) => !isLotteryOpenNow(l)).map((lottery) => {
                    const status = getLotteryStatus(lottery);
                    return (
                      <div key={lottery.id} className="w-full flex items-center gap-3 p-3 rounded-xl border border-gray-200 bg-gray-50 opacity-60">
                        <div className="w-6 h-6 rounded-md border-2 border-gray-300 flex items-center justify-center shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-gray-500">{lottery.name}</p>
                          <p className="text-[10px] text-red-400 font-bold">{status.countdown}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            <div className="p-3 border-t border-gray-100">
              <button onClick={() => setShowLotteryModal(false)} className="w-full py-2.5 bg-green-600 text-white rounded-xl font-bold text-sm hover:bg-green-700">
                {selectedLotteries.length} loteria(s) seleccionada(s) - Listo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Modal */}
      {showConfirmModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-5">
            <h3 className="font-bold text-lg text-gray-900 text-center mb-3">Confirmar Ticket</h3>
            <p className="text-sm text-gray-600 text-center mb-4">{plays.length} jugada(s) por <strong className="text-green-700">${formatMoney(total)}</strong></p>
            <div className="bg-gray-50 rounded-lg p-3 mb-4 max-h-32 overflow-y-auto">
              {plays.map((p, i) => (<div key={i} className="flex justify-between text-xs py-0.5"><span className="text-gray-700">{p.number} ({p.type})</span><span className="text-green-700 font-medium">${formatMoney(p.amount)}</span></div>))}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowConfirmModal(false)} className="flex-1 py-3 rounded-xl bg-gray-100 text-gray-700 font-bold text-sm hover:bg-gray-200">Cancelar</button>
              <button onClick={confirmSave} className="flex-1 py-3 rounded-xl bg-green-600 text-white font-bold text-sm hover:bg-green-700">Confirmar</button>
            </div>
          </div>
        </div>
      )}

      {/* Ticket Generated Modal */}
      {showTicketModal && lastTicket && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-5">
            <div className="text-center mb-4">
              <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-3"><Check size={32} className="text-green-600" /></div>
              <h3 className="font-bold text-xl text-gray-900">Ticket Guardado!</h3>
              <p className="text-sm text-gray-500 mt-1">{lastTicket.code}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-3 mb-4 space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Fecha:</span><span className="font-medium">{lastTicket.date}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Hora:</span><span className="font-medium">{lastTicket.time}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Terminal:</span><span className="font-medium">{lastTicket.terminal}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Vendedor:</span><span className="font-medium">{lastTicket.seller}</span></div>
              {lastTicket.groupName && <div className="flex justify-between"><span className="text-gray-500">Grupo:</span><span className="font-medium text-green-700">{lastTicket.groupName}</span></div>}
              <div className="flex justify-between"><span className="text-gray-500">Loteria:</span><span className="font-medium">{lastTicket.lottery}</span></div>
              <div className="flex justify-between border-t border-gray-200 pt-1 mt-1"><span className="text-gray-700 font-bold">Total:</span><span className="font-bold text-green-700">${formatMoney(Number(lastTicket.total))}</span></div>
            </div>
            <div className="flex justify-center mb-4">
              <QRDisplay ticket={lastTicket} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => downloadPDF(lastTicket)} className="py-3 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 flex items-center justify-center gap-2"><FileText size={16} /> PDF</button>
              <button onClick={shareWhatsApp} className="py-3 rounded-xl bg-green-600 text-white font-bold text-sm hover:bg-green-700 flex items-center justify-center gap-2"><Share2 size={16} /> WhatsApp</button>
            </div>
            <button onClick={() => setShowTicketModal(false)} className="w-full mt-2 py-2.5 rounded-xl bg-gray-100 text-gray-700 font-bold text-sm hover:bg-gray-200">Cerrar</button>
          </div>
        </div>
      )}
    </div>
  );
}

// QR Display component
function QRDisplay({ ticket }: { ticket: any }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (canvasRef.current && ticket) {
      const qrData = `TICKET:${ticket.code}|DATE:${ticket.date}|TIME:${ticket.time}|TERMINAL:${ticket.terminal}|TOTAL:${ticket.total}`;
      QRCode.toCanvas(canvasRef.current, qrData, { width: 150, margin: 2 }, (err: Error | null) => { if (err) console.error("QR Error:", err); });
    }
  }, [ticket]);
  return <canvas ref={canvasRef} className="rounded-lg" />;
}
