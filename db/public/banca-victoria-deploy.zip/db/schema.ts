import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
  bigint,
  mysqlEnum,
  decimal,
} from "drizzle-orm/mysql-core";

// ── AUTH USERS (from Kimi OAuth) ──────────────────────────────────────
export const authUsers = mysqlTable("auth_users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ── LOTTERY USERS (banca system) ──────────────────────────────────────
export const lotteryUsers = mysqlTable("lottery_users", {
  id: serial("id").primaryKey(),
  bankNumber: varchar("bank_number", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 30 }),
  role: mysqlEnum("lottery_role", ["admin", "supervisor", "collector", "user"]).default("user").notNull(),
  groupId: bigint("group_id", { mode: "number", unsigned: true }).references(() => groups.id),
  credit: decimal("credit", { precision: 12, scale: 2 }).default("500.00").notNull(),
  commission: decimal("commission", { precision: 5, scale: 2 }).default("10.00").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── GROUPS ────────────────────────────────────────────────────────────
export const groups = mysqlTable("groups", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  maxSalesPerDay: decimal("max_sales_per_day", { precision: 12, scale: 2 }).default("50000.00"),
  playLimitDirecto: int("play_limit_directo").default(1000),
  playLimitPale: int("play_limit_pale").default(500),
  playLimitTripleta: int("play_limit_tripleta").default(300),
  playLimitCuatrena: int("play_limit_cuatrena").default(200),
  playLimitTerna: int("play_limit_terna").default(200),
  enableDirecto: boolean("enable_directo").default(true),
  enablePale: boolean("enable_pale").default(true),
  enableTripleta: boolean("enable_tripleta").default(true),
  enableCuatrena: boolean("enable_cuatrena").default(true),
  enableTerna: boolean("enable_terna").default(true),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── LOTTERIES ─────────────────────────────────────────────────────────
export const lotteries = mysqlTable("lotteries", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  drawTime: varchar("draw_time", { length: 10 }).default("12:00").notNull(),
  openTime: varchar("open_time", { length: 10 }).default("06:00").notNull(),
  closeTime: varchar("close_time", { length: 10 }).default("11:00").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── TICKETS ───────────────────────────────────────────────────────────
export const tickets = mysqlTable("tickets", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 30 }).notNull().unique(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull().references(() => lotteryUsers.id),
  lotteryId: bigint("lottery_id", { mode: "number", unsigned: true }).notNull().references(() => lotteries.id),
  total: decimal("total", { precision: 10, scale: 2 }).default("0.00").notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "paid", "winner"]).default("active").notNull(),
  annulledBy: bigint("annulled_by", { mode: "number", unsigned: true }).references(() => lotteryUsers.id),
  annulledAt: timestamp("annulled_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── PLAYS (individual plays within a ticket) ──────────────────────────
export const plays = mysqlTable("plays", {
  id: serial("id").primaryKey(),
  ticketId: bigint("ticket_id", { mode: "number", unsigned: true }).notNull().references(() => tickets.id),
  number: varchar("number", { length: 50 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).default("0.00").notNull(),
  type: mysqlEnum("play_type", ["directo", "pale", "tripleta", "cuatrena", "terna"]).default("directo").notNull(),
  lotteryId: bigint("lottery_id", { mode: "number", unsigned: true }).notNull().references(() => lotteries.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── WINNERS (draw results) ────────────────────────────────────────────
export const winners = mysqlTable("winners", {
  id: serial("id").primaryKey(),
  lotteryId: bigint("lottery_id", { mode: "number", unsigned: true }).notNull().references(() => lotteries.id),
  firstPrize: varchar("first_prize", { length: 10 }).notNull(),
  secondPrize: varchar("second_prize", { length: 10 }).notNull(),
  thirdPrize: varchar("third_prize", { length: 10 }).notNull(),
  drawDate: varchar("draw_date", { length: 15 }).notNull(),
  createdBy: bigint("created_by", { mode: "number", unsigned: true }).references(() => lotteryUsers.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── PRIZES (payout multipliers per play type) ──────────────────────────
export const prizes = mysqlTable("prizes", {
  id: serial("id").primaryKey(),
  playType: mysqlEnum("play_type", ["directo", "pale", "tripleta", "cuatrena", "terna"]).notNull(),
  // Directo prizes
  firstPrizeMultiplier: decimal("first_prize_multiplier", { precision: 10, scale: 2 }).default("50.00"),
  secondPrizeMultiplier: decimal("second_prize_multiplier", { precision: 10, scale: 2 }).default("15.00"),
  thirdPrizeMultiplier: decimal("third_prize_multiplier", { precision: 10, scale: 2 }).default("10.00"),
  // Pale combination prizes (pair multipliers)
  paleFirstSecondMultiplier: decimal("pale_first_second", { precision: 10, scale: 2 }).default("25.00"),
  paleFirstThirdMultiplier: decimal("pale_first_third", { precision: 10, scale: 2 }).default("0.00"),
  paleSecondThirdMultiplier: decimal("pale_second_third", { precision: 10, scale: 2 }).default("0.00"),
  // Fixed multipliers for other types
  fixedMultiplier: decimal("fixed_multiplier", { precision: 12, scale: 2 }).default("0.00"),
  // For terna (3 cifras) = 500x, cuatrena = 4000x
  // For directo we use first/second/third, for pale we use pale combinations
  // For tripleta/cuatrena/terna we use fixedMultiplier
  description: varchar("description", { length: 255 }),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ── CONFIG (global settings) ──────────────────────────────────────────
export const config = mysqlTable("config", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ── Types ─────────────────────────────────────────────────────────────
export type AuthUser = typeof authUsers.$inferSelect;
export type LotteryUser = typeof lotteryUsers.$inferSelect;
export type Group = typeof groups.$inferSelect;
export type Lottery = typeof lotteries.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type Play = typeof plays.$inferSelect;
export type Winner = typeof winners.$inferSelect;
export type Config = typeof config.$inferSelect;
export type Prize = typeof prizes.$inferSelect;
