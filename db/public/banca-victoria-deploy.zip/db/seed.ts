import { getDb } from "../api/queries/connection";
import { lotteries, lotteryUsers, groups } from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // Seed default group
  const groupResult = await db.insert(groups).values({
    name: "Grupo Principal",
    maxSalesPerDay: "50000.00",
    active: true,
  });
  const groupId = Number(groupResult[0].insertId);
  console.log("Created default group with id:", groupId);

  // Seed admin user
  await db.insert(lotteryUsers).values({
    bankNumber: "B-001",
    name: "Administrador",
    username: "admin",
    password: "admin123",
    phone: "",
    role: "admin",
    groupId: groupId,
    credit: "100000.00",
    commission: "0",
    active: true,
  });
  console.log("Created admin user (username: admin, password: admin123)");

  // Seed default lotteries
  await db.insert(lotteries).values([
    { name: "Loteria Nacional Noche", drawTime: "20:55", openTime: "06:00", closeTime: "20:45", active: true },
    { name: "Loteria Nacional Tarde", drawTime: "14:55", openTime: "06:00", closeTime: "14:45", active: true },
    { name: "Leidsa", drawTime: "20:55", openTime: "06:00", closeTime: "20:45", active: true },
    { name: "Loteria Real", drawTime: "12:55", openTime: "06:00", closeTime: "12:45", active: true },
    { name: "Loteka", drawTime: "19:55", openTime: "06:00", closeTime: "19:45", active: true },
    { name: "La Primera", drawTime: "11:55", openTime: "06:00", closeTime: "11:45", active: true },
    { name: "La Suerte", drawTime: "12:55", openTime: "06:00", closeTime: "12:45", active: true },
    { name: "LoteDom", drawTime: "20:00", openTime: "06:00", closeTime: "19:45", active: true },
    { name: "Anguilla", drawTime: "10:00", openTime: "06:00", closeTime: "09:45", active: true },
    { name: "New York Tarde", drawTime: "14:30", openTime: "06:00", closeTime: "14:15", active: true },
    { name: "New York Noche", drawTime: "22:30", openTime: "06:00", closeTime: "22:15", active: true },
    { name: "Florida Tarde", drawTime: "13:30", openTime: "06:00", closeTime: "13:15", active: true },
    { name: "Florida Noche", drawTime: "21:45", openTime: "06:00", closeTime: "21:30", active: true },
  ]);
  console.log("Created 13 default lotteries");

  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed error:", err);
  process.exit(1);
});
