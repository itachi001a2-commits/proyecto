import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { lotteries } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const lotteryRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(lotteries).orderBy(desc(lotteries.createdAt));
  }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      drawTime: z.string().min(1),
      openTime: z.string().min(1),
      closeTime: z.string().min(1),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(lotteries).values({
        name: input.name,
        drawTime: input.drawTime,
        openTime: input.openTime,
        closeTime: input.closeTime,
        active: true,
      });
      return { id: Number(result[0].insertId) };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      drawTime: z.string().optional(),
      openTime: z.string().optional(),
      closeTime: z.string().optional(),
      active: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(lotteries).set(data).where(eq(lotteries.id, id));
      return { ok: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(lotteries).where(eq(lotteries.id, input.id));
      return { ok: true };
    }),
});
