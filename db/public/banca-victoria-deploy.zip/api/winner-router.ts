import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { winners } from "@db/schema";
import { eq, desc, and } from "drizzle-orm";

export const winnerRouter = createRouter({
  list: publicQuery
    .input(z.object({
      lotteryId: z.number().optional(),
      drawDate: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.lotteryId && input?.drawDate) {
        return db.select().from(winners)
          .where(and(eq(winners.lotteryId, input.lotteryId), eq(winners.drawDate, input.drawDate)))
          .orderBy(desc(winners.createdAt));
      }
      if (input?.lotteryId) {
        return db.select().from(winners)
          .where(eq(winners.lotteryId, input.lotteryId))
          .orderBy(desc(winners.createdAt));
      }
      return db.select().from(winners).orderBy(desc(winners.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      lotteryId: z.number(),
      firstPrize: z.string().min(1),
      secondPrize: z.string().min(1),
      thirdPrize: z.string().min(1),
      drawDate: z.string().min(1),
      createdBy: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(winners).values({
        lotteryId: input.lotteryId,
        firstPrize: input.firstPrize,
        secondPrize: input.secondPrize,
        thirdPrize: input.thirdPrize,
        drawDate: input.drawDate,
        createdBy: input.createdBy || null,
      });
      return { id: Number(result[0].insertId) };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(winners).where(eq(winners.id, input.id));
      return { ok: true };
    }),
});
