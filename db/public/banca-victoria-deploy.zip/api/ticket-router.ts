import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { tickets, plays } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const ticketRouter = createRouter({
  // Create ticket with plays
  create: publicQuery
    .input(z.object({
      code: z.string().min(1),
      userId: z.number(),
      lotteryId: z.number(),
      total: z.string(),
      playList: z.array(z.object({
        number: z.string(),
        amount: z.string(),
        type: z.enum(["directo", "pale", "tripleta", "cuatrena", "terna"]),
        lotteryId: z.number(),
      })),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const ticketResult = await db.insert(tickets).values({
        code: input.code,
        userId: input.userId,
        lotteryId: input.lotteryId,
        total: input.total,
        status: "active",
      });
      const ticketId = Number(ticketResult[0].insertId);
      
      for (const play of input.playList) {
        await db.insert(plays).values({
          ticketId,
          number: play.number,
          amount: play.amount,
          type: play.type,
          lotteryId: play.lotteryId,
        });
      }
      return { ticketId, code: input.code };
    }),

  // List tickets
  list: publicQuery
    .input(z.object({
      userId: z.number().optional(),
      status: z.enum(["active", "cancelled", "paid", "winner"]).optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      let query = db.select().from(tickets).orderBy(desc(tickets.createdAt));
      if (input?.userId) {
        return db.select().from(tickets)
          .where(eq(tickets.userId, input.userId))
          .orderBy(desc(tickets.createdAt));
      }
      return query;
    }),

  // Get ticket with plays
  withPlays: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const ticketRows = await db.select().from(tickets).where(eq(tickets.id, input.id));
      const playRows = await db.select().from(plays).where(eq(plays.ticketId, input.id));
      return { ticket: ticketRows[0] || null, plays: playRows };
    }),

  // Annul ticket
  annul: publicQuery
    .input(z.object({ id: z.number(), annulledBy: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(tickets).set({
        status: "cancelled",
        annulledBy: input.annulledBy,
        annulledAt: new Date(),
      }).where(eq(tickets.id, input.id));
      return { ok: true };
    }),

  // Update status
  updateStatus: publicQuery
    .input(z.object({ id: z.number(), status: z.enum(["active", "paid", "winner"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(tickets).set({ status: input.status }).where(eq(tickets.id, input.id));
      return { ok: true };
    }),
});
